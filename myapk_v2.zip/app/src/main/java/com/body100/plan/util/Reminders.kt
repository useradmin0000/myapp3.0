package com.body100.plan.util

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import com.body100.plan.receiver.AlarmReceiver
import java.util.Calendar

object Reminders {

    data class Point(val key: String, val minute: Int, val title: String)

    val POINTS = listOf(
        Point("r1", 6 * 60 + 30, "起床！喝300ml温水，如厕"),
        Point("r2", 7 * 60, "早餐时间，一天不能省的一餐"),
        Point("r3", 11 * 60 + 30, "午餐：少油少盐，半份主食"),
        Point("r4", 12 * 60, "午休30分钟，别刷手机"),
        Point("r5", 17 * 60, "加餐：水果+坚果 或 无糖酸奶"),
        Point("r6", 19 * 60 + 20, "晚餐清淡，现在开始吃，19:30前结束"),
        Point("r7", 20 * 60 + 30, "训练时间（休息日做拉伸）"),
        Point("r8", 21 * 60 + 30, "拉伸 + 泡脚，准备收工"),
        Point("r9", 22 * 60, "放下手机，开始洗漱"),
        Point("r10", 22 * 60 + 25, "5分钟后必须上床")
    )

    fun hhmm(min: Int) = String.format(java.util.Locale.CHINA, "%02d:%02d", min / 60, min % 60)

    private fun piFlags(): Int {
        var f = PendingIntent.FLAG_UPDATE_CURRENT
        if (Build.VERSION.SDK_INT >= 23) f = f or PendingIntent.FLAG_IMMUTABLE
        return f
    }

    private fun pointPi(ctx: Context, idx: Int): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java).apply {
            data = Uri.parse("body100://point/$idx")
            putExtra("kind", "point")
            putExtra("idx", idx)
        }
        return PendingIntent.getBroadcast(ctx, 100 + idx, i, piFlags())
    }

    private fun checkupPi(ctx: Context): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java).apply {
            data = Uri.parse("body100://checkup")
            putExtra("kind", "checkup")
        }
        return PendingIntent.getBroadcast(ctx, 200, i, piFlags())
    }

    private fun weeklyPi(ctx: Context): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java).apply {
            data = Uri.parse("body100://weekly")
            putExtra("kind", "weekly")
        }
        return PendingIntent.getBroadcast(ctx, 300, i, piFlags())
    }

    fun canExact(ctx: Context): Boolean = try {
        if (Build.VERSION.SDK_INT >= 31) {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.canScheduleExactAlarms()
        } else true
    } catch (e: Exception) { true }

    fun openExactSettings(ctx: Context) {
        try {
            val i = if (Build.VERSION.SDK_INT >= 31)
                Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                    .setData(Uri.parse("package:${ctx.packageName}"))
            else Intent(Settings.ACTION_SETTINGS)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } catch (e: Exception) {
            try {
                ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e2: Exception) { }
        }
    }

    fun openBatterySettings(ctx: Context) {
        try {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(ctx.packageName)) {
                val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:${ctx.packageName}"))
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
                return
            }
        } catch (e: Exception) { }
        try {
            ctx.startActivity(
                Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) { }
    }

    fun batteryOk(ctx: Context): Boolean = try {
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        pm.isIgnoringBatteryOptimizations(ctx.packageName)
    } catch (e: Exception) { true }

    private fun set(am: AlarmManager, at: Long, pi: PendingIntent) {
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (e: SecurityException) {
            try { am.set(AlarmManager.RTC_WAKEUP, at, pi) } catch (e2: Exception) { }
        } catch (e: Exception) { }
    }

    /** 排定单个提醒点的下一次触发 */
    fun schedulePoint(ctx: Context, idx: Int) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val p = POINTS[idx]
        if (!Prefs.alarmOn(ctx, p.key)) {
            try { am.cancel(pointPi(ctx, idx)) } catch (e: Exception) { }
            return
        }
        val m = (p.minute - Prefs.earlyMinutes(ctx)).coerceAtLeast(0)
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, m / 60)
            set(Calendar.MINUTE, m % 60)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (cal.timeInMillis <= System.currentTimeMillis() + 1500) {
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        set(am, cal.timeInMillis, pointPi(ctx, idx))
    }

    /** 21:00 打卡补漏 */
    fun scheduleCheckup(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (!Prefs.checkupOn(ctx)) {
            try { am.cancel(checkupPi(ctx)) } catch (e: Exception) { }
            return
        }
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 21)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (cal.timeInMillis <= System.currentTimeMillis() + 1500) cal.add(Calendar.DAY_OF_YEAR, 1)
        set(am, cal.timeInMillis, checkupPi(ctx))
    }

    /** 周日 20:00 周记录 */
    fun scheduleWeekly(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (!Prefs.weeklyOn(ctx)) {
            try { am.cancel(weeklyPi(ctx)) } catch (e: Exception) { }
            return
        }
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 20)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val add = (Calendar.SUNDAY - cal.get(Calendar.DAY_OF_WEEK) + 7) % 7
        cal.add(Calendar.DAY_OF_YEAR, add)
        if (cal.timeInMillis <= System.currentTimeMillis() + 1500) cal.add(Calendar.DAY_OF_YEAR, 7)
        set(am, cal.timeInMillis, weeklyPi(ctx))
    }

    fun rescheduleAll(ctx: Context) {
        val on = Prefs.alarmsEnabled(ctx)
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (i in POINTS.indices) {
            try { am.cancel(pointPi(ctx, i)) } catch (e: Exception) { }
            if (on) schedulePoint(ctx, i)
        }
        scheduleCheckup(ctx)
        scheduleWeekly(ctx)
    }

    fun nextUpText(ctx: Context): String {
        if (!Prefs.alarmsEnabled(ctx)) return "提醒已关闭"
        val now = Calendar.getInstance()
        val cur = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        val early = Prefs.earlyMinutes(ctx)
        var best = Int.MAX_VALUE
        var bestIdx = -1
        for (i in POINTS.indices) {
            val p = POINTS[i]
            if (!Prefs.alarmOn(ctx, p.key)) continue
            val m = (p.minute - early).coerceAtLeast(0)
            if (m > cur && m < best) { best = m; bestIdx = i }
        }
        if (bestIdx >= 0) return hhmm(best) + "  " + POINTS[bestIdx].title
        for (i in POINTS.indices) {
            val p = POINTS[i]
            if (!Prefs.alarmOn(ctx, p.key)) continue
            val m = (p.minute - early).coerceAtLeast(0)
            return "明天 " + hhmm(m) + "  " + p.title
        }
        return "没有启用的提醒"
    }
}
