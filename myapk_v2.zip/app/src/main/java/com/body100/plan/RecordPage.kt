package com.body100.plan

import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.lifecycle.lifecycleScope
import com.body100.plan.ui.Anim
import com.body100.plan.ui.LineChart
import com.body100.plan.ui.PlanViewModel
import com.body100.plan.ui.Ui
import com.body100.plan.util.Fx
import com.body100.plan.util.Prefs
import kotlinx.coroutines.launch
import java.util.Locale

class RecordPage(
    private val act: MainActivity,
    private val vm: PlanViewModel,
    private val ui: Ui
) {

    private val badges = listOf(
        Triple("s3", "坚持 3 天", "🌱"),
        Triple("s7", "坚持 7 天", "🌿"),
        Triple("s14", "适应期完成", "🌟"),
        Triple("s30", "坚持 30 天", "🔥"),
        Triple("s50", "坚持 50 天", "💪"),
        Triple("s100", "百日达成", "🏆"),
        Triple("perfect_day", "满分一天", "✅")
    )

    fun build(): LinearLayout {
        val p = ui.page()
        val day = Prefs.dayIndex(act)
        val week = Prefs.weekIndex(act)

        val hero = ui.card().apply { background = ui.round(ui.purple, 20f) }
        hero.addView(ui.tv("第 $week 周记录", 19f, 0xFFFFFFFF.toInt(), true))
        hero.addView(ui.tv("每周日填写 · 周日 20:00 自动提醒", 13f, 0xCCFFFFFF.toInt()))
        p.addView(hero)

        p.addView(ui.section("本周填写"))
        val form = ui.card()

        val wIn = ui.input("例：54.2", "")
        wIn.inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        val gIn = ui.input("例：78", "")
        gIn.inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        val fIn = ui.input("睡得好不好？训练累不累？", "", true)

        form.addView(ui.tv("体重（kg）", 14f, ui.ink, true))
        form.addView(wIn)
        form.addView(ui.gap(10f))
        form.addView(ui.tv("腰围（cm）", 14f, ui.ink, true))
        form.addView(gIn)
        form.addView(ui.gap(10f))
        form.addView(ui.tv("本周感受", 14f, ui.ink, true))
        form.addView(fIn)

        act.lifecycleScope.launchWhenStarted {
            vm.records().collect { list ->
                val cur = list.firstOrNull { it.week == week }
                if (cur != null) {
                    if (wIn.text.isNullOrEmpty()) wIn.setText(cur.weight)
                    if (gIn.text.isNullOrEmpty()) gIn.setText(cur.waist)
                    if (fIn.text.isNullOrEmpty()) fIn.setText(cur.feel)
                }
            }
        }

        val save = ui.button("保存第 $week 周记录", ui.purple, 0xFFFFFFFF.toInt())
        save.setOnClickListener {
            vm.saveRecord(
                week,
                wIn.text.toString().trim(),
                gIn.text.toString().trim(),
                fIn.text.toString().trim()
            )
            Fx.playCheck()
            Fx.tap(act)
            Anim.press(it)
            act.toast("已保存第 $week 周记录")
        }
        form.addView(save, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = ui.dp(12f) })
        p.addView(form)

        p.addView(ui.section("变化趋势"))
        val chartCard = ui.card()

        chartCard.addView(ui.tv("体重（kg）", 14f, ui.ink, true))
        val weightChart = LineChart(act).apply {
            lineColor = ui.blue
            fillColor = ui.alpha(ui.blue, 0.14f)
            labelColor = ui.ink3
        }
        chartCard.addView(weightChart, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(160f)).apply { topMargin = ui.dp(8f) })

        chartCard.addView(ui.tv("腰围（cm）", 14f, ui.ink, true).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = ui.dp(14f) }
        })
        val waistChart = LineChart(act).apply {
            lineColor = ui.orange
            fillColor = ui.alpha(ui.orange, 0.14f)
            labelColor = ui.ink3
        }
        chartCard.addView(waistChart, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(160f)).apply { topMargin = ui.dp(8f) })

        val cmpText = ui.tv("", 13f, ui.ink2)
        chartCard.addView(cmpText, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = ui.dp(10f) })
        p.addView(chartCard)

        act.lifecycleScope.launchWhenStarted {
            vm.records().collect { list ->
                val wp = list.mapNotNull { r ->
                    r.weight.toFloatOrNull()?.let { LineChart.Pt(r.week, it) }
                }
                val gp = list.mapNotNull { r ->
                    r.waist.toFloatOrNull()?.let { LineChart.Pt(r.week, it) }
                }
                weightChart.points = wp
                waistChart.points = gp

                if (list.size >= 2) {
                    val f = list.first()
                    val l = list.last()
                    val dw = (l.weight.toFloatOrNull() ?: 0f) - (f.weight.toFloatOrNull() ?: 0f)
                    val dg = (l.waist.toFloatOrNull() ?: 0f) - (f.waist.toFloatOrNull() ?: 0f)
                    cmpText.text = String.format(
                        Locale.CHINA,
                        "第%d周 到 第%d周\n体重 %+.1f kg　腰围 %+.1f cm",
                        f.week, l.week, dw, dg
                    )
                } else {
                    cmpText.text = "至少记录 2 周才能看到趋势"
                }
            }
        }

        p.addView(ui.section("成就徽章"))
        val badgeCard = ui.card()
        val unlocked = Prefs.unlockedBadges(act)
        val grid = ui.vbox()
        var row: LinearLayout? = null
        badges.forEachIndexed { i, b ->
            if (i % 3 == 0) {
                val r = ui.hbox()
                grid.addView(r, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = ui.dp(8f) })
                row = r
            }
            val on = b.first in unlocked
            val cell = ui.vbox().apply { gravity = Gravity.CENTER }
            cell.setPadding(ui.dp(4f), ui.dp(10f), ui.dp(4f), ui.dp(10f))
            val icon = ui.tv(b.third, 30f, if (on) ui.ink else ui.ink3).apply {
                gravity = Gravity.CENTER
                alpha = if (on) 1f else 0.28f
            }
            val label = ui.tv(b.second, 11f, if (on) ui.ink else ui.ink3).apply {
                gravity = Gravity.CENTER
            }
            cell.addView(icon)
            cell.addView(label)
            row?.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        badgeCard.addView(grid)
        badgeCard.addView(ui.tv("积分：${Prefs.points(act)}", 13f, ui.green, true).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = ui.dp(10f) }
        })
        p.addView(badgeCard)

        p.addView(ui.section("14 周记录表"))
        val table = ui.card()
        val wRows = ArrayList<TextView>()
        val gRows = ArrayList<TextView>()
        for (i in 1..14) {
            val cur = i == week
            val row = ui.hbox()
            val t = ui.tv("第${i}周", 13.5f, if (cur) ui.purple else ui.ink, cur)
            t.width = ui.dp(66f)
            row.addView(t)
            val wTv = ui.tv("体重 —", 13.5f, ui.ink2)
            val gTv = ui.tv("腰围 —", 13.5f, ui.ink2)
            row.addView(wTv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(gTv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.setPadding(0, ui.dp(5f), 0, ui.dp(5f))
            table.addView(row)
            wRows.add(wTv)
            gRows.add(gTv)
        }
        p.addView(table)

        act.lifecycleScope.launchWhenStarted {
            vm.records().collect { list ->
                for (i in 1..14) {
                    val r = list.firstOrNull { it.week == i }
                    wRows[i - 1].text = if (r == null || r.weight.isEmpty()) "体重 —" else "${r.weight}kg"
                    gRows[i - 1].text = if (r == null || r.waist.isEmpty()) "腰围 —" else "${r.waist}cm"
                }
            }
        }

        p.addView(ui.section("累计成绩"))
        val stat = ui.card()
        val statTitle = ui.tv("", 15f, ui.ink, true)
        val statSub = ui.tv("", 14f, ui.ink2)
        stat.addView(statTitle)
        stat.addView(statSub)
        val pb = ui.progress(100)
        pb.progress = day
        stat.addView(pb, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(8f)).apply { topMargin = ui.dp(10f) })
        p.addView(stat)

        act.lifecycleScope.launch {
            val perfect = vm.perfectDays()
            val streak = vm.streak()
            statTitle.text = "已完成 $perfect 个完整打卡日"
            statSub.text = "当前连续 $streak 天 · 进度第 $day / 100 天"
        }

        Anim.stagger(p, 20L)
        return p
    }
}
