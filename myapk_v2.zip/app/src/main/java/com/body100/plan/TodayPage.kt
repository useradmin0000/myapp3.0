package com.body100.plan

import android.app.AlertDialog
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.lifecycle.lifecycleScope
import com.body100.plan.ui.Anim
import com.body100.plan.ui.PlanViewModel
import com.body100.plan.ui.Ui
import com.body100.plan.util.Fx
import com.body100.plan.util.Notify
import com.body100.plan.util.Prefs
import com.body100.plan.util.Reminders
import kotlinx.coroutines.launch

class TodayPage(
    private val act: MainActivity,
    private val vm: PlanViewModel,
    private val ui: Ui,
    private val curDate: String?
) {

    private val date: String get() = curDate ?: Prefs.today()
    private val isToday: Boolean get() = date == Prefs.today()

    fun build(): LinearLayout {
        val p = ui.page()
        val day = Prefs.dayIndex(act)

        // ---- 顶部进度卡 ----
        val hero = ui.card().apply { background = ui.round(ui.green, 20f) }
        val row = ui.hbox()
        row.addView(ui.tv("第 $day / 100 天", 21f, 0xFFFFFFFF.toInt(), true),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val stage = ui.tv(Plan.stage(day), 11f, 0xFFFFFFFF.toInt(), true).apply {
            background = ui.round(0x33FFFFFF, 20f)
            setPadding(ui.dp(9f), ui.dp(3f), ui.dp(9f), ui.dp(4f))
        }
        row.addView(stage)
        hero.addView(row)

        val goals = Plan.stageGoals(day)
        hero.addView(ui.tv(goals[1], 13f, 0xCCFFFFFF.toInt()).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = ui.dp(6f) }
        })

        val pb = ui.progress(Plan.CHECKS.size)
        hero.addView(pb, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(8f)).apply { topMargin = ui.dp(14f) })

        val totalTv = ui.tv("0 / ${Plan.CHECKS.size} 项完成", 13f, 0xFFFFFFFF.toInt(), true)
        val streakTv = ui.tv("连续 0 天", 13f, 0xCCFFFFFF.toInt())
        val nums = ui.hbox()
        nums.addView(totalTv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        nums.addView(streakTv)
        hero.addView(nums, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = ui.dp(8f) })
        p.addView(hero)

        // ---- 天气 ----
        val weatherCard = ui.card()
        val wRow = ui.hbox()
        val wIcon = ui.tv("🌡", 22f, ui.ink)
        val wText = ui.tv("正在获取天气…", 14f, ui.ink2)
        val wAdvice = ui.tv("", 12.5f, ui.ink3)
        wRow.addView(wIcon)
        wRow.addView(ui.wgap(10f))
        val wCol = ui.vbox()
        wCol.addView(wText)
        wCol.addView(wAdvice)
        wRow.addView(wCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        weatherCard.addView(wRow)
        p.addView(weatherCard)

        act.lifecycleScope.launchWhenStarted {
            vm.weather.collect { w ->
                if (w != null) {
                    wIcon.text = w.icon
                    wText.text = "${w.temp}°C  ${w.text}"
                    wAdvice.text = w.advice
                } else {
                    val cached = Prefs.lastWeather(act)
                    if (cached.isNotEmpty()) wText.text = cached else wText.text = "天气获取失败（可点设置关掉）"
                }
            }
        }

        // ---- 提醒状态 ----
        val notif = Notify.enabled(act)
        val exact = Reminders.canExact(act)
        val batt = Reminders.batteryOk(act)
        val allOk = notif && exact && batt && Prefs.alarmsEnabled(act)

        val st = ui.card()
        val stRow = ui.hbox()
        stRow.addView(ui.tv("●", 12f, if (allOk) ui.green else ui.orange))
        stRow.addView(ui.wgap(6f))
        val msg = when {
            !Prefs.alarmsEnabled(act) -> "提醒已关闭"
            !notif -> "通知权限未开，提醒发不出来"
            !exact -> "精确闹钟未开，提醒可能延迟"
            !batt -> "建议关闭电池优化，避免被杀"
            else -> "提醒已就绪（${Reminders.POINTS.size} 个时间点）"
        }
        stRow.addView(ui.tv(msg, 13f, ui.ink2),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val goBtn = ui.tv(if (allOk) "详情" else "去修复", 13f, ui.green, true)
        goBtn.setOnClickListener { act.goTab(4) }
        stRow.addView(goBtn)
        st.addView(stRow)
        st.addView(ui.tv("下一条：${Reminders.nextUpText(act)}", 12f, ui.ink3))
        p.addView(st)

        // ---- 饮水 ----
        val wCard = ui.card()
        val wTop = ui.hbox()
        wTop.addView(ui.tv("今日饮水", 15f, ui.ink, true),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val wVal = ui.tv("0 ml / 2000 ml", 13f, ui.ink2)
        wTop.addView(wVal)
        wCard.addView(wTop)
        val wBar = ui.progress(2000)
        wCard.addView(wBar, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(6f)).apply { topMargin = ui.dp(8f) })
        val wBtns = ui.hbox()
        val add250 = ui.button("+250ml", ui.blue, 0xFFFFFFFF.toInt())
        add250.setOnClickListener {
            vm.addWater(Prefs.today(), 250)
            Anim.press(it)
            Fx.playCheck()
            Fx.tap(act)
        }
        val undo = ui.ghost("撤销", ui.ink2)
        undo.setOnClickListener { vm.undoWater(Prefs.today()) }
        wBtns.addView(add250, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        wBtns.addView(ui.wgap(8f))
        wBtns.addView(undo, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        wCard.addView(wBtns, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = ui.dp(10f) })
        p.addView(wCard)

        act.lifecycleScope.launchWhenStarted {
            vm.waterOf(Prefs.today()).collect { list ->
                val sum = list.sumOf { it.ml }
                wVal.text = "$sum ml / 2000 ml"
                ValAnimate(wBar, sum.coerceAtMost(2000))
            }
        }

        // ---- 打卡清单 ----
        p.addView(ui.section(if (isToday) "今日打卡" else "历史打卡 · $date"))

        val listCard = ui.card()
        val checkRows = ArrayList<Pair<CheckBox, TextView>>()

        for (c in Plan.CHECKS) {
            val cb = ui.check(c.title, false, true)
            cb.setOnClickListener {
                val nowChecked = cb.isChecked
                Anim.pop(it)
                if (nowChecked) {
                    Fx.playCheck()
                    Fx.tap(act)
                } else {
                    Fx.playUncheck()
                    Fx.cancel(act)
                }
                vm.toggleCheck(date, c.id)
            }
            listCard.addView(cb)
            val tip = ui.tv("    提醒时间 ${c.time}", 12f, ui.ink3)
            tip.setPadding(ui.dp(12f), 0, 0, ui.dp(6f))
            listCard.addView(tip)
            checkRows.add(cb to tip)
        }
        p.addView(listCard)

        // 监听数据库变化刷新勾选
        act.lifecycleScope.launchWhenStarted {
            vm.checksOf(date).collect { list ->
                val done = list.filter { it.done }.map { it.itemId }.toSet()
                for (i in Plan.CHECKS.indices) {
                    val cb = checkRows[i].first
                    val tip = checkRows[i].second
                    val ok = Plan.CHECKS[i].id in done
                    if (cb.isChecked != ok) cb.isChecked = ok
                    cb.setTextColor(if (ok) ui.ink3 else ui.ink)
                    if (ok) {
                        cb.paintFlags = cb.paintFlags or android.graphics.Paint.STRIKE_THRU_TEXT_FLAG
                    } else {
                        cb.paintFlags = cb.paintFlags and android.graphics.Paint.STRIKE_THRU_TEXT_FLAG.inv()
                    }
                    tip.visibility = if (ok) View.GONE else View.VISIBLE
                }
                val n = done.size
                ValAnimate(pb, n)
                totalTv.text = "$n / ${Plan.CHECKS.size} 项完成"
                act.lifecycleScope.launch {
                    streakTv.text = "连续 ${vm.streak()} 天"
                }
            }
        }

        // ---- 红线 ----
        p.addView(ui.section("红线（违反即当日作废）"))
        val redCard = ui.card().apply { background = ui.round(if (ui.dark) 0xFF2A1A1A.toInt() else 0xFFFDF3F3.toInt(), 14f) }
        for (r in Plan.RED_LINES) {
            redCard.addView(ui.tv("✕  $r", 14f, ui.ink))
        }
        val voidBtn = ui.button("我今天违反了红线 → 当日作废", ui.red, 0xFFFFFFFF.toInt())
        voidBtn.setOnClickListener { confirmVoid() }
        redCard.addView(voidBtn, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = ui.dp(10f) })
        p.addView(redCard)

        act.lifecycleScope.launchWhenStarted {
            vm.flagOf(date).collect { f ->
                val v = f?.voided == true
                voidBtn.text = if (v) "已作废（点此取消）" else "我今天违反了红线 → 当日作废"
                voidBtn.setBackgroundColor(if (v) ui.ink3 else ui.red)
                voidBtn.setOnClickListener {
                    if (v) {
                        vm.setVoided(date, false)
                    } else confirmVoid()
                }
            }
        }

        // ---- 作息表 ----
        p.addView(ui.section("今日作息表（固定）"))
        for (it in Plan.schedule()) {
            val color = ui.colorOf(it.color)
            var howView: TextView? = null
            val outer = ui.barCard(color) { c ->
                val head = ui.hbox()
                head.addView(ui.tv(it.range, 12.5f, color, true))
                head.addView(ui.wgap(10f))
                head.addView(ui.tv(it.title, 15f, ui.ink, true),
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                c.addView(head)
                c.addView(ui.tv(it.detail, 13f, ui.ink2).apply {
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { topMargin = ui.dp(4f) }
                })
                val how = ui.tv("怎么做 →", 12f, color, true)
                c.addView(how, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = ui.dp(6f) })
                howView = how
            }
            val show = View.OnClickListener {
                AlertDialog.Builder(act)
                    .setTitle("${it.range}  ${it.title}")
                    .setMessage("${it.detail}\n\n【怎么做】\n${it.howto}")
                    .setPositiveButton("知道了", null)
                    .show()
            }
            howView?.setOnClickListener(show)
            outer.setOnClickListener(show)
            p.addView(outer)
        }

        // ---- 硬性规则 ----
        p.addView(ui.section("必须遵守的硬性规则"))
        val rules = ui.card()
        Plan.RULES.forEachIndexed { i, r -> rules.addView(ui.tv("${i + 1}. $r", 14f, ui.ink)) }
        p.addView(rules)

        // ---- 阶段要点 ----
        p.addView(ui.section("当前阶段要点"))
        val why = ui.card()
        why.addView(ui.tv("核心根基", 15f, ui.green, true))
        why.addView(ui.tv(
            "22:30上床睡觉、06:30起床。做不到这一条，其余全部白费。\n" +
                    "每天4餐 + 早睡早起 + 20:30固定训练，形成闭环。", 14f, ui.ink2))
        why.addView(ui.divider())
        goals.forEach { why.addView(ui.tv("· $it", 14f, ui.ink2)) }
        why.addView(ui.divider())
        why.addView(ui.tv("脱发与湿气", 15f, ui.ink, true))
        why.addView(ui.tv("脱发：靠「不熬夜 + 营养均衡 + 戒酒」改善。100天内若仍明显，去皮肤科查雄激素水平。", 14f, ui.ink2))
        why.addView(ui.tv("湿气（齿痕舌）：根源是熬夜 + 重油重盐 + 喝酒。坚持第3-4周，齿痕变浅、身体变轻松。", 14f, ui.ink2))
        p.addView(why)

        Anim.stagger(p, 20L)
        return p
    }

    private fun ValAnimate(pb: ProgressBar, to: Int) {
        pb.progress = to
    }

    private fun confirmVoid() {
        AlertDialog.Builder(act)
            .setTitle("确认当日作废？")
            .setMessage("按手册规则：违反任意一条红线，当天计划作废，次日重新开始。\n\n" +
                    "你确实违反了以下之一吗？\n· 熬夜超过22:30\n· 不吃早餐\n· 喝酒\n" +
                    "· 含糖饮料\n· 油炸/红烧/糖醋\n· 19:30后进食")
            .setNegativeButton("没有，手滑了", null)
            .setPositiveButton("确实违反了") { _, _ ->
                vm.setVoided(date, true)
                Fx.playWarn()
                Fx.alarm(act)
                act.toast("已作废，明天重新开始")
            }
            .show()
    }
}
