package com.body100.plan.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.body100.plan.Plan
import com.body100.plan.data.CheckEntity
import com.body100.plan.data.DayFlagEntity
import com.body100.plan.data.PlanDb
import com.body100.plan.data.RecordEntity
import com.body100.plan.data.TrainingLogEntity
import com.body100.plan.data.WaterEntity
import com.body100.plan.net.Weather
import com.body100.plan.util.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PlanViewModel(app: Application) : AndroidViewModel(app) {

    private val dao = PlanDb.get(app).dao()
    val appCtx = app.applicationContext

    private val _weather = MutableStateFlow<Weather.Info?>(null)
    val weather: StateFlow<Weather.Info?> = _weather

    private val _weatherLoading = MutableStateFlow(false)
    val weatherLoading: StateFlow<Boolean> = _weatherLoading

    // ---------- 打卡 ----------
    fun checksOf(date: String): Flow<List<CheckEntity>> = dao.checksOf(date)

    fun flagOf(date: String): Flow<DayFlagEntity?> = dao.flagOf(date)

    fun toggleCheck(date: String, itemId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val cur = dao.checksOfOnce(date).firstOrNull { it.itemId == itemId }
            val nowDone = !(cur?.done ?: false)
            dao.upsert(
                CheckEntity(
                    key = "$date#$itemId",
                    date = date,
                    itemId = itemId,
                    done = nowDone,
                    updatedAt = System.currentTimeMillis()
                )
            )
            if (nowDone) Prefs.addPoints(appCtx, 10)
            val count = dao.doneCount(date)
            checkBadges(count)
        }
    }

    fun setChecked(date: String, itemId: String, done: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            dao.upsert(
                CheckEntity("$date#$itemId", date, itemId, done, System.currentTimeMillis())
            )
        }
    }

    fun setVoided(date: String, v: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            val old = dao.flagOfOnce(date)
            dao.upsertFlag(DayFlagEntity(date, v, old?.note ?: ""))
        }
    }

    /** 连续完整打卡天数 */
    suspend fun streak(): Int = withContext(Dispatchers.IO) {
        var n = 0
        val total = Plan.CHECKS.size
        for (i in 0 until 365) {
            val d = Prefs.dayKey(-i)
            val cnt = dao.doneCount(d)
            val flag = dao.flagOfOnce(d)
            val ok = cnt >= total && (flag?.voided != true)
            if (ok) n++
            else if (i == 0) continue
            else break
        }
        n
    }

    suspend fun perfectDays(): Int = withContext(Dispatchers.IO) {
        var n = 0
        val total = Plan.CHECKS.size
        for (i in 0 until 100) {
            val d = Prefs.dayKey(-i)
            if (dao.doneCount(d) >= total && dao.flagOfOnce(d)?.voided != true) n++
        }
        n
    }

    private suspend fun checkBadges(doneCount: Int) {
        val total = Plan.CHECKS.size
        if (doneCount >= total) {
            Prefs.unlockBadge(appCtx, "perfect_day")
            val s = streak()
            val map = mapOf(3 to "s3", 7 to "s7", 14 to "s14", 30 to "s30", 50 to "s50", 100 to "s100")
            map[s]?.let { Prefs.unlockBadge(appCtx, it) }
        }
    }

    /** 公开调用：解锁徽章（供页面使用） */
    fun refreshBadges() {
        viewModelScope.launch(Dispatchers.IO) {
            try { checkBadges(dao.doneCount(Prefs.today())) } catch (e: Exception) { }
        }
    }

    /** 将某天某项目设为完成（供通知快捷打卡） */
    fun checkItem(date: String, itemId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                dao.upsert(CheckEntity("$date#$itemId", date, itemId, true, System.currentTimeMillis()))
                Prefs.addPoints(appCtx, 10)
            } catch (e: Exception) { }
        }
    }

    // ---------- 周记录 ----------
    fun records(): Flow<List<RecordEntity>> = dao.records()

    suspend fun recordsOnce(): List<RecordEntity> = withContext(Dispatchers.IO) { dao.recordsOnce() }

    fun saveRecord(week: Int, weight: String, waist: String, feel: String) {
        viewModelScope.launch(Dispatchers.IO) {
            dao.upsertRecord(RecordEntity(week, weight, waist, feel, System.currentTimeMillis()))
        }
    }

    // ---------- 饮水 ----------
    fun waterOf(date: String): Flow<List<WaterEntity>> = dao.waterOf(date)

    fun addWater(date: String, ml: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            dao.addWater(WaterEntity(date = date, ml = ml, at = System.currentTimeMillis()))
        }
    }

    fun undoWater(date: String) {
        viewModelScope.launch(Dispatchers.IO) { dao.removeLastWater(date) }
    }

    // ---------- 训练日志 ----------
    fun trainingOf(date: String): Flow<List<TrainingLogEntity>> = dao.trainingOf(date)

    fun logTraining(date: String, moveName: String, sets: Int, reps: String) {
        viewModelScope.launch(Dispatchers.IO) {
            dao.addTraining(
                TrainingLogEntity(date = date, moveName = moveName, sets = sets, reps = reps,
                    at = System.currentTimeMillis())
            )
        }
    }

    // ---------- 天气 ----------
    fun refreshWeather() {
        if (!Prefs.weatherOn(appCtx)) return
        viewModelScope.launch {
            _weatherLoading.value = true
            val w = Weather.fetch(appCtx)
            _weatherLoading.value = false
            if (w != null) {
                _weather.value = w
                Prefs.setLastWeather(appCtx, "${w.icon} ${w.temp}°C ${w.text}")
            }
        }
    }
}
