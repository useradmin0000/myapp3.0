package com.body100.plan.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.body100.plan.data.CheckEntity
import com.body100.plan.data.PlanDb
import com.body100.plan.util.Fx
import com.body100.plan.util.Notify
import com.body100.plan.util.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

/** 通知上的「已打卡」快捷按钮 */
class CheckActionReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent?) {
        val itemId = intent?.getStringExtra("itemId") ?: return
        val date = intent.getStringExtra("date") ?: Prefs.today()
        GlobalScope.launch(Dispatchers.IO) {
            try {
                PlanDb.get(ctx).dao().upsert(
                    CheckEntity(
                        key = "$date#$itemId",
                        date = date,
                        itemId = itemId,
                        done = true,
                        updatedAt = System.currentTimeMillis()
                    )
                )
                Prefs.addPoints(ctx, 10)
                Fx.playCheck()
                Fx.tap(ctx)
                Notify.cancel(ctx, intent.getIntExtra("notifId", 0))
            } catch (e: Exception) { }
        }
    }
}
