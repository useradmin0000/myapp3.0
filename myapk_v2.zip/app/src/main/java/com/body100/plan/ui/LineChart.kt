package com.body100.plan.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View

/**
 * 极简折线图：体重 / 腰围趋势。数据点 {week, value}。
 */
class LineChart(ctx: Context) : View(ctx) {

    data class Pt(val week: Int, val value: Float)

    var points: List<Pt> = emptyList()
        set(v) { field = v; invalidate() }

    var lineColor: Int = 0xFF2E6BE6.toInt()
    var fillColor: Int = 0x332E6BE6.toInt()
    var labelColor: Int = 0xFF9AA5A0.toInt()
    var goalLine: Float? = null
    var goalColor: Int = 0x55D64545.toInt()

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.4f * resources.displayMetrics.density
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val dotRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.4f * resources.displayMetrics.density
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 10f * resources.displayMetrics.scaledDensity
        textAlign = Paint.Align.CENTER
    }
    private val goalPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.2f * resources.displayMetrics.density
        pathEffect = android.graphics.DashPathEffect(floatArrayOf(8f, 8f), 0f)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (points.isEmpty()) {
            textPaint.color = labelColor
            canvas.drawText("还没有数据", width / 2f, height / 2f, textPaint)
            return
        }

        val d = resources.displayMetrics.density
        val padL = 30f * d
        val padR = 12f * d
        val padT = 14f * d
        val padB = 22f * d
        val w = width - padL - padR
        val h = height - padT - padB
        if (w <= 0 || h <= 0) return

        val minV = points.minOf { it.value }
        val maxV = points.maxOf { it.value }
        var lo = minV
        var hi = maxV
        if (hi - lo < 1f) { lo -= 0.5f; hi += 0.5f }
        val span = hi - lo

        fun xOf(i: Int): Float = padL + if (points.size == 1) w / 2f else w * i / (points.size - 1).toFloat()
        fun yOf(v: Float): Float = padT + h * (1f - (v - lo) / span)

        // 目标线
        goalLine?.let { g ->
            if (g in lo..hi) {
                goalPaint.color = goalColor
                canvas.drawLine(padL, yOf(g), padL + w, yOf(g), goalPaint)
            }
        }

        // 折线 + 填充
        val path = Path()
        val fill = Path()
        points.forEachIndexed { i, pt ->
            val x = xOf(i)
            val y = yOf(pt.value)
            if (i == 0) {
                path.moveTo(x, y)
                fill.moveTo(x, padT + h)
                fill.lineTo(x, y)
            } else {
                path.lineTo(x, y)
                fill.lineTo(x, y)
            }
        }
        fill.lineTo(xOf(points.size - 1), padT + h)
        fill.close()

        linePaint.color = lineColor
        fillPaint.color = fillColor
        canvas.drawPath(fill, fillPaint)
        canvas.drawPath(path, linePaint)

        // 点 + 数值
        dotPaint.color = lineColor
        dotRing.color = Color.WHITE
        textPaint.color = labelColor
        points.forEachIndexed { i, pt ->
            val x = xOf(i)
            val y = yOf(pt.value)
            canvas.drawCircle(x, y, 4f * d, dotPaint)
            canvas.drawCircle(x, y, 4f * d, dotRing)
            canvas.drawText(
                String.format(java.util.Locale.CHINA, "%.1f", pt.value),
                x, y - 8f * d, textPaint
            )
            if (points.size <= 8 || i % 2 == 0 || i == points.size - 1) {
                canvas.drawText("${pt.week}周", x, padT + h + 14f * d, textPaint)
            }
        }
    }
}
