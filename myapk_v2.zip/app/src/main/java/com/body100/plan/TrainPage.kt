package com.body100.plan

import android.app.AlertDialog
import android.graphics.Color
import android.os.CountDownTimer
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.lifecycle.lifecycleScope
import com.body100.plan.net.ExerciseImages
import com.body100.plan.ui.Anim
import com.body100.plan.ui.PlanViewModel
import com.body100.plan.ui.Ui
import com.body100.plan.util.Fx
import com.body100.plan.util.Prefs
import java.util.Calendar
import kotlinx.coroutines.launch

class TrainPage(
    private val act: MainActivity,
    private val vm: PlanViewModel,
    private val ui: Ui
) {

    private var timer: CountDownTimer? = null

    fun build(): LinearLayout {
        val p = ui.page()
        val dow = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)
        val day = Prefs.dayIndex(act)
        val w = Plan.workout(dow)

        // ---- 顶部 ----
        val hero = ui.card().apply { background = ui.round(ui.blue, 20f) }
        hero.addView(ui.tv("${w.day} · ${w.title}", 19f, 0xFFFFFFFF.toInt(), true))
        hero.addView(ui.tv("${w.duration}   |   ${w.slot}", 13f, 0xCCFFFFFF.toInt()))
        val scale = ui.tv(Plan.scale(day), 12f, 0xFFFFFFFF.toInt()).apply {
            background = ui.round(0x33FFFFFF, 10f)
            setPadding(ui.dp(10f), ui.dp(10f), ui.dp(10f), ui.dp(10f))
        }
        hero.addView(scale, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = ui.dp(10f) })
        p.addView(hero)

        // ---- 组间计时器 ----
        p.addView(ui.section("组间休息计时"))
        val tCard = ui.card()
        val tRow = ui.hbox()
        val tDisplay = ui.tv("60", 40f, ui.blue, true).apply {
            gravity = Gravity.CENTER
        }
        tRow.addView(tDisplay, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val tUnit = ui.tv(" 秒", 15f, ui.ink3)
        val tWrap = ui.vbox()
        tWrap.addView(tRow)
        tCard.addView(tWrap, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val tBtns = ui.hbox()
        val b60 = ui.button("60秒", ui.blue, 0xFFFFFFFF.toInt())
        val b90 = ui.button("90秒", ui.blue, 0xFFFFFFFF.toInt())
        val bStop = ui.ghost("重置", ui.ink2)
        b60.setOnClickListener { startTimer(60, tDisplay) }
        b90.setOnClickListener { startTimer(90, tDisplay) }
        bStop.setOnClickListener {
            timer?.cancel()
            tDisplay.text = "60"
            b60.isEnabled = true
            b90.isEnabled = true
        }
        tBtns.addView(b60, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tBtns.addView(ui.wgap(8f))
        tBtns.addView(b90, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tBtns.addView(ui.wgap(8f))
        tBtns.addView(bStop, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tCard.addView(tBtns, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = ui.dp(12f) })
        p.addView(tCard)

        // ---- 动作清单（带示范图）----
        p.addView(ui.section("动作清单（点击看示范）"))
        for (m in w.moves) {
            val c = ui.card()

            val head = ui.hbox()
            head.addView(ui.tv(m.name, 16f, ui.ink, true),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            head.addView(ui.chip(m.sets, ui.blue))
            c.addView(head)

            c.addView(ui.tv(m.how, 13f, ui.ink2).apply {
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = ui.dp(6f) }
            })

            if (m.image != null) {
                val iv = ImageView(act).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    background = ui.round(ui.alpha(ui.blue, 0.08f), 12f)
                }
                c.addView(iv, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(180f)).apply { topMargin = ui.dp(10f) })
                ExerciseImages.load(iv, m.image, 0)

                val tip = ui.tv("图片来自 free-exercise-db（公有领域）", 11f, ui.ink3)
                tip.setPadding(0, ui.dp(6f), 0, 0)
                c.addView(tip)

                val demoBtn = ui.ghost("查看动作示范", ui.blue)
                demoBtn.setOnClickListener {
                    showDemo(m)
                }
                c.addView(demoBtn, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = ui.dp(8f) })
            }

            val logBtn = ui.ghost("记录完成一组", ui.green)
            logBtn.setOnClickListener {
                vm.logTraining(Prefs.today(), m.name, 1, m.sets)
                Fx.playCheck()
                Fx.tap(act)
                Anim.press(it)
                act.toast("已记录：${m.name}")
            }
            c.addView(logBtn, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = ui.dp(8f) })

            p.addView(c)
        }

        // ---- 要点 ----
        p.addView(ui.section("要点与热身"))
        val notes = ui.card()
        for (n in w.notes) notes.addView(ui.tv("· $n", 14f, ui.ink2))
        notes.addView(ui.divider())
        notes.addView(ui.tv("练前热身（2分钟）", 15f, ui.ink, true))
        notes.addView(ui.tv("肩绕环20次 → 髋绕环10次 → 原地高抬腿30秒 → 手腕脚踝各转一圈。", 13f, ui.ink2))
        p.addView(notes)

        // ---- 今日训练日志 ----
        p.addView(ui.section("今日训练记录"))
        val logCard = ui.card()
        val logEmpty = ui.tv("还没有记录，做完一组点「记录完成一组」", 13f, ui.ink3)
        logCard.addView(logEmpty)
        p.addView(logCard)

        act.lifecycleScope.launchWhenStarted {
            vm.trainingOf(Prefs.today()).collect { list ->
                logCard.removeAllViews()
                if (list.isEmpty()) {
                    logCard.addView(ui.tv("还没有记录，做完一组点「记录完成一组」", 13f, ui.ink3))
                } else {
                    for (t in list) {
                        val row = ui.hbox()
                        row.addView(ui.tv("✓ ${t.moveName}", 14f, ui.ink),
                            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                        row.addView(ui.tv(t.reps, 12f, ui.ink3))
                        row.setPadding(0, ui.dp(5f), 0, ui.dp(5f))
                        logCard.addView(row)
                    }
                }
            }
        }

        // ---- 本周安排 ----
        p.addView(ui.section("本周训练安排"))
        val week = ui.card()
        val order = listOf("周一", "周二", "周三", "周四", "周五", "周六", "周日")
        val info = listOf(
            "胸部+上肢 40min", "核心（腹部）35min", "下肢+臀部 40min",
            "休息日（拉伸15min）", "全身HIIT 25min", "胸部+核心 40min", "休息日（散步/拉伸）"
        )
        for (i in 0..6) {
            val cdow = i + 2
            val today = cdow == dow
            val row = ui.hbox()
            row.addView(ui.tv("${order[i]}   ${info[i]}", 13.5f, if (today) ui.blue else ui.ink, today),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            if (today) row.addView(ui.chip("今天", ui.blue))
            row.setPadding(0, ui.dp(6f), 0, ui.dp(6f))
            week.addView(row)
        }
        p.addView(week)

        // ---- 训练打卡 ----
        val tc = ui.card()
        val cb = ui.check("今天完成训练 / 拉伸", false, true)
        cb.setOnClickListener {
            Fx.playCheck()
            Fx.tap(act)
            Anim.pop(it)
            vm.toggleCheck(Prefs.today(), "train")
        }
        tc.addView(cb)
        p.addView(tc)

        act.lifecycleScope.launchWhenStarted {
            vm.checksOf(Prefs.today()).collect { list ->
                val ok = list.firstOrNull { it.itemId == "train" }?.done == true
                if (cb.isChecked != ok) cb.isChecked = ok
                cb.setTextColor(if (ok) ui.ink3 else ui.ink)
            }
        }

        Anim.stagger(p, 20L)
        return p
    }

    private fun startTimer(seconds: Int, display: TextView) {
        timer?.cancel()
        timer = object : CountDownTimer(seconds * 1000L, 1000L) {
            override fun onTick(millisUntilFinished: Long) {
                val s = (millisUntilFinished / 1000).toInt() + 1
                display.text = s.toString()
                display.setTextColor(if (s <= 3) ui.red else ui.blue)
                if (s <= 3) Fx.tap(act)
            }

            override fun onFinish() {
                display.text = "0"
                display.setTextColor(ui.green)
                Fx.playCelebrate()
                Fx.alarm(act)
                act.toast("休息结束，开始下一组！")
            }
        }.start()
    }

    private fun showDemo(m: Plan.Move) {
        val iv = ImageView(act).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
        }
        ExerciseImages.load(iv, m.image, 0)
        val iv2 = ImageView(act).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
        }
        ExerciseImages.load(iv2, m.image, 1)

        val box = ui.vbox().apply {
            setPadding(ui.dp(8f), ui.dp(8f), ui.dp(8f), ui.dp(8f))
        }
        val row = ui.hbox()
        row.addView(iv, LinearLayout.LayoutParams(0, ui.dp(180f), 1f))
        row.addView(ui.wgap(6f))
        row.addView(iv2, LinearLayout.LayoutParams(0, ui.dp(180f), 1f))
        box.addView(row)
        box.addView(ui.tv("\n要领\n${m.how}", 14f, ui.ink2))
        box.addView(ui.tv("\n组次：${m.sets}", 14f, ui.blue, true))

        AlertDialog.Builder(act)
            .setTitle(m.name)
            .setView(box)
            .setPositiveButton("知道了", null)
            .show()
    }
}
