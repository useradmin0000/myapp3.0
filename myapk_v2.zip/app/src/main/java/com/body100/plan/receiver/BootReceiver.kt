package com.body100.plan.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.body100.plan.util.Notify
import com.body100.plan.util.Reminders

/** 开机 / 更新 / 时间变更后重排闹钟 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent?) {
        try {
            Notify.ensure(ctx)
            Reminders.rescheduleAll(ctx)
        } catch (e: Exception) { }
    }
}
