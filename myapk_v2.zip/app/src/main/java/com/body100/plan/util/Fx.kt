package com.body100.plan.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin

/**
 * 音效与震动：全部用 AudioTrack 实时合成，不依赖任何音频文件。
 */
object Fx {

    private const val RATE = 44100

    @Volatile private var soundOn = true
    @Volatile private var vibrateOn = true

    fun setSound(on: Boolean) { soundOn = on }
    fun setVibrate(on: Boolean) { vibrateOn = on }

    // ---------------- 震动 ----------------
    private fun vib(ctx: Context): Vibrator? {
        return try {
            if (Build.VERSION.SDK_INT >= 31) {
                val m = ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                m?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
        } catch (e: Exception) { null }
    }

    /** 打卡：短促一下 */
    fun tap(ctx: Context) {
        if (!vibrateOn) return
        buzz(ctx, longArrayOf(0, 28))
    }

    /** 取消：双短 */
    fun cancel(ctx: Context) {
        if (!vibrateOn) return
        buzz(ctx, longArrayOf(0, 18, 60, 18))
    }

    /** 红线作废：重震动 */
    fun alarm(ctx: Context) {
        if (!vibrateOn) return
        buzz(ctx, longArrayOf(0, 60, 80, 60, 80, 160))
    }

    /** 提醒到点：长震动循环模式 */
    fun reminder(ctx: Context) {
        if (!vibrateOn) return
        buzz(ctx, longArrayOf(0, 400, 200, 400, 200, 600))
    }

    private fun buzz(ctx: Context, pattern: LongArray) {
        try {
            val v = vib(ctx) ?: return
            if (!v.hasVibrator()) return
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createWaveform(pattern, -1))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(pattern, -1)
            }
        } catch (e: Exception) { }
    }

    // ---------------- 音效（合成） ----------------
    private fun play(buf: ShortArray, volume: Float = 0.7f) {
        GlobalScope.launch(Dispatchers.Default) {
            try {
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(RATE)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .setBufferSizeInBytes(buf.size * 2)
                    .build()
                track.write(buf, 0, buf.size)
                track.setVolume(volume)
                track.play()
                Thread.sleep((buf.size * 1000L / RATE) + 180)
                try { track.stop() } catch (e: Exception) { }
                track.release()
            } catch (e: Exception) { }
        }
    }

    /** 短促“叮” 880Hz，120ms 衰减 */
    private fun ding(): ShortArray {
        val n = RATE * 12 / 100
        val out = ShortArray(n)
        for (i in 0 until n) {
            val t = i.toDouble() / RATE
            val env = Math.exp(-t * 26.0)
            val s = sin(2 * PI * 880 * t) * 0.6 + sin(2 * PI * 1760 * t) * 0.15
            out[i] = (s * env * 30000).toInt().toShort()
        }
        return out
    }

    /** 低沉“嗒” 440Hz，70ms */
    private fun tapSound(): ShortArray {
        val n = RATE * 7 / 100
        val out = ShortArray(n)
        for (i in 0 until n) {
            val t = i.toDouble() / RATE
            val env = Math.exp(-t * 55.0)
            val s = sin(2 * PI * 440 * t)
            out[i] = (s * env * 22000).toInt().toShort()
        }
        return out
    }

    /** 警示：660 → 440 双音下行 */
    private fun warn(): ShortArray {
        val n = RATE * 40 / 100
        val out = ShortArray(n)
        for (i in 0 until n) {
            val t = i.toDouble() / RATE
            val f = if (t < 0.18) 660.0 else 440.0
            val env = if (t < 0.18) Math.exp(-(t) * 8.0) else Math.exp(-(t - 0.18) * 8.0)
            val s = sin(2 * PI * f * t)
            out[i] = (s * env * 26000).toInt().toShort()
        }
        return out
    }

    /** 庆祝：上行琶音 */
    private fun fanfare(): ShortArray {
        val notes = doubleArrayOf(523.25, 659.25, 783.99, 1046.5)
        val seg = RATE * 11 / 100
        val out = ShortArray(seg * notes.size)
        for (k in notes.indices) {
            for (i in 0 until seg) {
                val t = i.toDouble() / RATE
                val env = Math.exp(-t * 14.0)
                val s = sin(2 * PI * notes[k] * t)
                out[k * seg + i] = (s * env * 26000).toInt().toShort()
            }
        }
        return out
    }

    fun playCheck() { if (soundOn) play(ding(), 0.55f) }
    fun playUncheck() { if (soundOn) play(tapSound(), 0.45f) }
    fun playWarn() { if (soundOn) play(warn(), 0.65f) }
    fun playCelebrate() { if (soundOn) play(fanfare(), 0.7f) }
}
