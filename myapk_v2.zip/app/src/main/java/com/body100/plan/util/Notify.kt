package com.body100.plan.util

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.AudioAttributes
import android.os.Build
import com.body100.plan.MainActivity
import com.body100.plan.R

object Notify {

    const val CH_PLAN = "plan"
    const val CH_CHECKUP = "checkup"

    fun ensure(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val plan = NotificationChannel(CH_PLAN, "计划提醒", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "每日作息 / 饮食 / 训练提醒"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 400, 200, 400, 200, 600)
                enableLights(true)
                lightColor = Color.GREEN
                setShowBadge(true)
                setSound(
                    android.provider.Settings.System.DEFAULT_NOTIFICATION_URI,
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .build()
                )
            }
            val checkup = NotificationChannel(CH_CHECKUP, "打卡补漏", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "每天 21:00 汇总未完成项"
                enableVibration(true)
            }
            nm.createNotificationChannel(plan)
            nm.createNotificationChannel(checkup)
        } catch (e: Exception) { }
    }

    private fun openPi(ctx: Context, req: Int): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        var f = PendingIntent.FLAG_UPDATE_CURRENT
        if (Build.VERSION.SDK_INT >= 23) f = f or PendingIntent.FLAG_IMMUTABLE
        return PendingIntent.getActivity(ctx, req, i, f)
    }

    /** 大标题通知：到点提醒 */
    fun post(ctx: Context, id: Int, title: String, short: String, big: String,
             channel: String = CH_PLAN, high: Boolean = true) {
        ensure(ctx)
        try {
            val b = if (Build.VERSION.SDK_INT >= 26) {
                Notification.Builder(ctx, channel)
            } else {
                @Suppress("DEPRECATION")
                Notification.Builder(ctx).apply {
                    priority = if (high) Notification.PRIORITY_HIGH else Notification.PRIORITY_DEFAULT
                    setDefaults(Notification.DEFAULT_ALL)
                }
            }
            @Suppress("DEPRECATION")
            b.setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(title)
                .setContentText(short)
                .setStyle(Notification.BigTextStyle().bigText(big))
                .setAutoCancel(true)
                .setShowWhen(true)
                .setContentIntent(openPi(ctx, id))
                .setCategory(Notification.CATEGORY_REMINDER)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(id, b.build())
        } catch (e: Exception) { }
    }

    fun cancel(ctx: Context, id: Int) {
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.cancel(id)
        } catch (e: Exception) { }
    }

    fun enabled(ctx: Context): Boolean = try {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.areNotificationsEnabled()
    } catch (e: Exception) { true }
}
