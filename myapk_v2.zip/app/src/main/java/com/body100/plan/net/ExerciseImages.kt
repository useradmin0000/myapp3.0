package com.body100.plan.net

import android.widget.ImageView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.request.RequestOptions

/**
 * 动作图片：来自 free-exercise-db（公有领域）。
 * 图片经由 raw.githubusercontent.com 加载，Glide 自动磁盘缓存，二次打开秒开。
 */
object ExerciseImages {

    private const val BASE = "https://raw.githubusercontent.com/yuhonas/free-exercise-db/main/exercises/"

    fun url(folder: String?, index: Int = 0): String? {
        if (folder.isNullOrEmpty()) return null
        return "$BASE${folder}/${index}.jpg"
    }

    fun load(iv: ImageView, folder: String?, index: Int = 0) {
        val u = url(folder, index)
        if (u == null) return
        Glide.with(iv)
            .load(u)
            .apply(
                RequestOptions()
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .centerCrop()
            )
            .transition(DrawableTransitionOptions.withCrossFade(220))
            .into(iv)
    }
}
