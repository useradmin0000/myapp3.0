package com.body100.plan

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.body100.plan.ui.Anim
import com.body100.plan.ui.PlanViewModel
import com.body100.plan.ui.Ui
import com.body100.plan.util.Fx
import com.body100.plan.util.Notify
import com.body100.plan.util.Prefs
import com.body100.plan.util.Reminders
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var vm: PlanViewModel
    private lateinit var ui: Ui
    private lateinit var root: FrameLayout
    private lateinit var content: LinearLayout
    private lateinit var nav: LinearLayout

    private var tab = 0
    private var curDate: String? = null

    private val TABS = listOf("今日", "训练", "饮食", "记录", "设置")

    private val permLauncher by lazy {
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            val loc = result[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                    result[Manifest.permission.ACCESS_COARSE_LOCATION] == true
            if (loc) vm.refreshWeather()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = Ui(this)
        vm = ViewModelProvider(this)[PlanViewModel::class.java]

        Fx.setSound(Prefs.soundOn(this))
        Fx.setVibrate(Prefs.vibrateOn(this))
        Notify.ensure(this)
        Prefs.startDate(this)
        Reminders.rescheduleAll(this)

        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN

        root = FrameLayout(this).apply { setBackgroundColor(ui.bg) }
        setContentView(root)

        content = ui.vbox()
        root.addView(content, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        nav = buildNav()
        root.addView(nav, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(60f)).apply {
            gravity = Gravity.BOTTOM
        })

        render()
        firstRun()
        vm.refreshWeather()
    }

    override fun onResume() {
        super.onResume()
        try { Reminders.rescheduleAll(this) } catch (e: Exception) { }
        render()
    }

    private fun statusTop(): Int {
        var h = 24
        try {
            val id = resources.getIdentifier("status_bar_height", "dimen", "android")
            if (id > 0) h = (resources.getDimensionPixelSize(id) / resources.displayMetrics.density).toInt()
        } catch (e: Exception) { }
        return ui.dp(h + 8f)
    }

    // ---------------- 导航 ----------------
    private fun buildNav(): LinearLayout {
        val bar = ui.hbox()
        bar.setBackgroundColor(ui.card)
        bar.elevation = ui.dp(8f).toFloat()
        for (i in TABS.indices) {
            val item = ui.vbox()
            item.gravity = Gravity.CENTER
            item.setPadding(0, ui.dp(8f), 0, ui.dp(6f))

            val dot = ui.tv("●", 9f, ui.green).apply { gravity = Gravity.CENTER }
            val label = ui.tv(TABS[i], 12f, ui.ink3).apply { gravity = Gravity.CENTER }
            item.addView(dot)
            item.addView(label)
            item.tag = arrayOf<View>(dot, label)
            val idx = i
            item.setOnClickListener {
                if (tab == idx) return@setOnClickListener
                tab = idx
                if (idx == 0) curDate = null
                Anim.press(it)
                render()
            }
            bar.addView(item, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        }
        return bar
    }

    private fun paintNav() {
        for (i in 0 until nav.childCount) {
            @Suppress("UNCHECKED_CAST")
            val tags = nav.getChildAt(i).tag as Array<View>
            val dot = tags[0] as TextView
            val label = tags[1] as TextView
            val on = i == tab
            dot.setTextColor(if (on) ui.green else ui.alpha(ui.ink3, 0.35f))
            label.setTextColor(if (on) ui.green else ui.ink3)
            label.typeface = if (on) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
    }

    fun render() {
        paintNav()
        content.removeAllViews()
        val sv: ScrollView = ui.scroll()
        val page: LinearLayout = when (tab) {
            1 -> TrainPage(this, vm, ui).build()
            2 -> MealPage(this, vm, ui).build()
            3 -> RecordPage(this, vm, ui).build()
            4 -> SettingsPage(this, vm, ui).build()
            else -> TodayPage(this, vm, ui, curDate).build()
        }
        page.setPadding(ui.dp(16f), statusTop(), ui.dp(16f), ui.dp(40f))
        sv.addView(page, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        content.addView(sv, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        content.setPadding(0, 0, 0, ui.dp(60f))
        Anim.enter(sv, 8f)
    }

    fun goTab(t: Int) { tab = t; render() }

    fun currentDate(): String = curDate ?: Prefs.today()

    fun setCurDate(d: String?) { curDate = d; render() }

    // ---------------- 首次运行 ----------------
    private fun firstRun() {
        if (Prefs.welcomed(this)) { askPermissions(); return }
        Prefs.setWelcomed(this)
        AlertDialog.Builder(this)
            .setTitle("百日计划 2.0")
            .setMessage("把手册变成「到点提醒 + 每日打卡」。\n\n" +
                    "· 今日：完整作息表，13 项打卡，饮水计数\n" +
                    "· 训练：今日动作 + 动作示范图 + 组间计时\n" +
                    "· 饮食：4 餐食谱，外卖话术一键复制\n" +
                    "· 记录：体重腰围趋势，成就徽章\n\n" +
                    "为了提醒准时响，需要：\n1. 通知权限\n2. 精确闹钟\n3. 忽略电池优化\n4. 定位（用于天气，可拒绝）")
            .setPositiveButton("去设置") { _, _ -> askPermissions() }
            .setNegativeButton("先看看", null)
            .show()
    }

    private fun askPermissions() {
        val need = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (need.isNotEmpty()) permLauncher.launch(need.toTypedArray())
        Notify.ensure(this)
    }

    fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
