package com.body100.plan.ui

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator

object Anim {

    /** 页面进入：淡入 + 上滑 */
    fun enter(v: View, offsetDp: Float = 12f) {
        val d = v.resources.displayMetrics.density
        v.alpha = 0f
        v.translationY = offsetDp * d
        v.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(180)
            .setInterpolator(DecelerateInterpolator())
            .start()
    }

    /** 列表依次进入 */
    fun stagger(container: ViewGroup, delayStep: Long = 28L, offsetDp: Float = 10f) {
        val d = container.resources.displayMetrics.density
        for (i in 0 until container.childCount) {
            val c = container.getChildAt(i)
            c.alpha = 0f
            c.translationY = offsetDp * d
            c.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(i * delayStep)
                .setDuration(200)
                .setInterpolator(DecelerateInterpolator())
                .start()
        }
    }

    /** 按压反馈 */
    fun press(v: View) {
        val set = AnimatorSet()
        val down = ObjectAnimator.ofFloat(v, View.SCALE_X, 0.965f).apply { duration = 70 }
        val downY = ObjectAnimator.ofFloat(v, View.SCALE_Y, 0.965f).apply { duration = 70 }
        val up = ObjectAnimator.ofFloat(v, View.SCALE_X, 1f).apply {
            duration = 140
            interpolator = OvershootInterpolator(2.2f)
        }
        val upY = ObjectAnimator.ofFloat(v, View.SCALE_Y, 1f).apply {
            duration = 140
            interpolator = OvershootInterpolator(2.2f)
        }
        set.play(down).with(downY)
        set.play(up).with(upY).after(down)
        set.start()
    }

    /** 勾选弹跳 */
    fun pop(v: View) {
        val set = AnimatorSet()
        val a = ObjectAnimator.ofFloat(v, View.SCALE_X, 1.15f).apply { duration = 90 }
        val b = ObjectAnimator.ofFloat(v, View.SCALE_Y, 1.15f).apply { duration = 90 }
        val c = ObjectAnimator.ofFloat(v, View.SCALE_X, 1f).apply {
            duration = 130
            interpolator = OvershootInterpolator(3f)
        }
        val d = ObjectAnimator.ofFloat(v, View.SCALE_Y, 1f).apply {
            duration = 130
            interpolator = OvershootInterpolator(3f)
        }
        set.play(a).with(b)
        set.play(c).with(d).after(a)
        set.start()
    }

    /** 进度动画 */
    fun progress(from: Int, to: Int, apply: (Int) -> Unit) {
        val anim = ValueAnimator.ofInt(from, to).apply {
            duration = 380
            interpolator = DecelerateInterpolator()
            addUpdateListener { apply(it.animatedValue as Int) }
        }
        anim.start()
    }
}
