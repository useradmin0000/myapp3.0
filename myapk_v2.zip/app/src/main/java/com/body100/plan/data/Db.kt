package com.body100.plan.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "checks")
data class CheckEntity(
    @PrimaryKey val key: String,
    val date: String,
    val itemId: String,
    val done: Boolean,
    val updatedAt: Long
)

@Entity(tableName = "day_flags")
data class DayFlagEntity(
    @PrimaryKey val date: String,
    val voided: Boolean,
    val note: String = ""
)

@Entity(tableName = "records")
data class RecordEntity(
    @PrimaryKey val week: Int,
    val weight: String = "",
    val waist: String = "",
    val feel: String = "",
    val updatedAt: Long = 0
)

@Entity(tableName = "water")
data class WaterEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,
    val ml: Int,
    val at: Long
)

@Entity(tableName = "training_log")
data class TrainingLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,
    val moveName: String,
    val sets: Int,
    val reps: String,
    val at: Long
)

@Dao
interface PlanDao {
    @Query("SELECT * FROM checks WHERE date = :date")
    fun checksOf(date: String): Flow<List<CheckEntity>>

    @Query("SELECT * FROM checks WHERE date = :date")
    suspend fun checksOfOnce(date: String): List<CheckEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(e: CheckEntity)

    @Query("SELECT COUNT(*) FROM checks WHERE done = 1 AND date = :date")
    suspend fun doneCount(date: String): Int

    @Query("SELECT date FROM checks WHERE done = 1 GROUP BY date HAVING COUNT(*) >= :total")
    suspend fun perfectDates(total: Int): List<String>

    @Query("SELECT * FROM day_flags WHERE date = :date")
    fun flagOf(date: String): Flow<DayFlagEntity?>

    @Query("SELECT * FROM day_flags WHERE date = :date")
    suspend fun flagOfOnce(date: String): DayFlagEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertFlag(e: DayFlagEntity)

    @Query("SELECT * FROM records ORDER BY week")
    fun records(): Flow<List<RecordEntity>>

    @Query("SELECT * FROM records ORDER BY week")
    suspend fun recordsOnce(): List<RecordEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertRecord(e: RecordEntity)

    @Query("SELECT * FROM water WHERE date = :date ORDER BY at")
    fun waterOf(date: String): Flow<List<WaterEntity>>

    @Insert
    suspend fun addWater(e: WaterEntity)

    @Query("DELETE FROM water WHERE date = :date AND id = (SELECT MAX(id) FROM water WHERE date = :date)")
    suspend fun removeLastWater(date: String)

    @Query("SELECT * FROM training_log WHERE date = :date ORDER BY at DESC")
    fun trainingOf(date: String): Flow<List<TrainingLogEntity>>

    @Insert
    suspend fun addTraining(e: TrainingLogEntity)
}

@Database(
    entities = [CheckEntity::class, DayFlagEntity::class, RecordEntity::class,
        WaterEntity::class, TrainingLogEntity::class],
    version = 1,
    exportSchema = false
)
abstract class PlanDb : RoomDatabase() {

    abstract fun dao(): PlanDao

    companion object {
        @Volatile private var INSTANCE: PlanDb? = null

        fun get(ctx: Context): PlanDb = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                ctx.applicationContext, PlanDb::class.java, "body100.db"
            ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
        }
    }
}
