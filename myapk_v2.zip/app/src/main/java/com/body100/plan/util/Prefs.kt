package com.body100.plan.util

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object Prefs {

    private const val NAME = "body100_prefs"
    private val DF = SimpleDateFormat("yyyy-MM-dd", Locale.CHINA)

    fun sp(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun today(): String = DF.format(Date())

    fun dayKey(offset: Int): String {
        val c = Calendar.getInstance()
        c.add(Calendar.DAY_OF_YEAR, offset)
        return DF.format(c.time)
    }

    fun startDate(ctx: Context): String {
        val s = sp(ctx)
        return s.getString("startDate", null) ?: today().also {
            s.edit().putString("startDate", it).apply()
        }
    }

    fun setStartDate(ctx: Context, d: String) {
        sp(ctx).edit().putString("startDate", d).apply()
    }

    fun dayIndex(ctx: Context): Int {
        return try {
            val st = DF.parse(startDate(ctx))!!
            val td = DF.parse(today())!!
            val diff = (td.time - st.time) / 86400000L
            (diff + 1).coerceIn(1L, 100L).toInt()
        } catch (e: Exception) { 1 }
    }

    fun weekIndex(ctx: Context): Int {
        val d = dayIndex(ctx)
        return ((d - 1) / 7 + 1).coerceIn(1, 14)
    }

    // 提醒开关
    fun alarmsEnabled(ctx: Context) = sp(ctx).getBoolean("alarms_enabled", true)
    fun setAlarmsEnabled(ctx: Context, on: Boolean) = sp(ctx).edit().putBoolean("alarms_enabled", on).apply()

    fun soundOn(ctx: Context) = sp(ctx).getBoolean("sound_on", true)
    fun setSoundOn(ctx: Context, on: Boolean) = sp(ctx).edit().putBoolean("sound_on", on).apply()

    fun vibrateOn(ctx: Context) = sp(ctx).getBoolean("vibrate_on", true)
    fun setVibrateOn(ctx: Context, on: Boolean) = sp(ctx).edit().putBoolean("vibrate_on", on).apply()

    fun checkupOn(ctx: Context) = sp(ctx).getBoolean("checkup_on", true)
    fun setCheckupOn(ctx: Context, on: Boolean) = sp(ctx).edit().putBoolean("checkup_on", on).apply()

    fun weeklyOn(ctx: Context) = sp(ctx).getBoolean("weekly_on", true)
    fun setWeeklyOn(ctx: Context, on: Boolean) = sp(ctx).edit().putBoolean("weekly_on", on).apply()

    fun earlyMinutes(ctx: Context) = sp(ctx).getInt("early_min", 0)
    fun setEarlyMinutes(ctx: Context, m: Int) =
        sp(ctx).edit().putInt("early_min", m.coerceIn(0, 60)).apply()

    fun alarmOn(ctx: Context, id: String) = sp(ctx).getBoolean("alarm_$id", true)
    fun setAlarmOn(ctx: Context, id: String, on: Boolean) =
        sp(ctx).edit().putBoolean("alarm_$id", on).apply()

    fun welcomed(ctx: Context) = sp(ctx).getBoolean("welcomed", false)
    fun setWelcomed(ctx: Context) = sp(ctx).edit().putBoolean("welcomed", true).apply()

    // 天气
    fun weatherOn(ctx: Context) = sp(ctx).getBoolean("weather_on", true)
    fun setWeatherOn(ctx: Context, on: Boolean) = sp(ctx).edit().putBoolean("weather_on", on).apply()

    fun lastWeather(ctx: Context): String = sp(ctx).getString("last_weather", "") ?: ""
    fun setLastWeather(ctx: Context, s: String) = sp(ctx).edit().putString("last_weather", s).apply()

    // 成就
    fun unlockedBadges(ctx: Context): Set<String> =
        sp(ctx).getStringSet("badges", emptySet()) ?: emptySet()

    fun unlockBadge(ctx: Context, id: String) {
        val cur = unlockedBadges(ctx).toMutableSet()
        if (cur.add(id)) sp(ctx).edit().putStringSet("badges", cur).apply()
    }

    // 积分
    fun points(ctx: Context) = sp(ctx).getInt("points", 0)
    fun addPoints(ctx: Context, p: Int) = sp(ctx).edit().putInt("points", points(ctx) + p).apply()
}
