package com.body100.plan.net

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * 天气：Open-Meteo，无需 API key。
 * 定位用 LocationManager.getLastKnownLocation，不引入 play-services。
 */
object Weather {

    private val client = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(6, TimeUnit.SECONDS)
        .build()

    data class Info(val temp: Int, val code: Int, val text: String, val advice: String, val icon: String)

    /** WMO 天气码 -> 中文 */
    private fun describe(code: Int): Triple<String, String, String> {
        return when (code) {
            0 -> Triple("晴", "☀", "天气好，训练可在户外")
            1, 2 -> Triple("多云", "⛅", "适合户外活动")
            3 -> Triple("阴", "☁", "注意补钙，多在户外走走")
            45, 48 -> Triple("雾", "🌫", "骑行送餐注意安全")
            51, 53, 55 -> Triple("毛毛雨", "🌦", "带伞，注意保暖")
            61, 63 -> Triple("小雨", "🌧", "带伞；室内做训练")
            65 -> Triple("大雨", "🌧", "避免户外，注意保暖")
            66, 67 -> Triple("冻雨", "🌧", "路面滑，谨慎骑行")
            71, 73, 75 -> Triple("雪", "❄", "注意防寒")
            80, 81, 82 -> Triple("阵雨", "🌦", "出门带伞")
            95, 96, 99 -> Triple("雷雨", "⛈", "避免户外，注意安全")
            else -> Triple("未知", "🌡", "")
        }
    }

    /** 高温/低温额外建议 */
    private fun extra(temp: Int): String = when {
        temp >= 33 -> " · 高温，送餐每小时补水，避免正午暴晒"
        temp >= 28 -> " · 天热，多喝500ml"
        temp <= 5 -> " · 很冷，注意保暖别感冒"
        temp <= 12 -> " · 天凉，出门加件外套"
        else -> ""
    }

    private fun lastLocation(ctx: Context): Pair<Double, Double>? {
        val fine = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) return null
        return try {
            val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            var loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            if (loc == null) loc = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            if (loc == null) loc = lm.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER)
            loc?.let { it.latitude to it.longitude }
        } catch (e: SecurityException) { null }
        catch (e: Exception) { null }
    }

    /** 取天气；失败返回 null。lat/lon 为空时用默认（深圳）。 */
    suspend fun fetch(ctx: Context): Info? = withContext(Dispatchers.IO) {
        try {
            val pos = lastLocation(ctx) ?: (22.5431 to 114.0579)
            val url = "https://api.open-meteo.com/v1/forecast" +
                    "?latitude=${pos.first}&longitude=${pos.second}" +
                    "&current=temperature_2m,weather_code&timezone=auto"
            val req = Request.Builder().url(url).header("User-Agent", "Body100/2.0").build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext null
                val body = resp.body?.string() ?: return@withContext null
                val cur = JSONObject(body).getJSONObject("current")
                val t = cur.getDouble("temperature_2m").toInt()
                val code = cur.getInt("weather_code")
                val (text, icon, advice) = describe(code)
                Info(t, code, text, advice + extra(t), icon)
            }
        } catch (e: Exception) { null }
    }
}
