package com.body100.plan.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.body100.plan.Plan
import com.body100.plan.data.PlanDb
import com.body100.plan.util.Fx
import com.body100.plan.util.Notify
import com.body100.plan.util.Prefs
import com.body100.plan.util.Reminders
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.util.Calendar

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(ctx: Context, intent: Intent?) {
        if (intent == null) return
        try {
            when (intent.getStringExtra("kind")) {
                "point" -> handlePoint(ctx, intent.getIntExtra("idx", -1))
                "checkup" -> handleCheckup(ctx)
                "weekly" -> handleWeekly(ctx)
            }
        } catch (e: Exception) { }
    }

    private fun handlePoint(ctx: Context, idx: Int) {
        if (idx < 0 || idx >= Reminders.POINTS.size) return
        val p = Reminders.POINTS[idx]
        Fx.reminder(ctx)
        Notify.post(
            ctx, 1000 + idx,
            Reminders.hhmm(p.minute) + " · " + p.title,
            p.title,
            detailOf(ctx, idx)
        )
        // 排下一天
        Reminders.schedulePoint(ctx, idx)
        // 睡前那条顺便全量校正一次
        if (idx == Reminders.POINTS.size - 1) Reminders.rescheduleAll(ctx)
    }

    private fun handleCheckup(ctx: Context) {
        val today = Prefs.today()
        GlobalScope.launch(Dispatchers.IO) {
            try {
                val dao = PlanDb.get(ctx).dao()
                val done = dao.checksOfOnce(today).filter { it.done }.map { it.itemId }.toSet()
                val missing = Plan.CHECKS.filter { it.id !in done }
                if (missing.size > 0) {
                    val list = missing.joinToString("\n") { "· " + it.title }
                    Notify.post(
                        ctx, 2000,
                        "今天还有 ${missing.size} 项没打卡",
                        "点击查看待完成清单",
                        "距离 22:30 还有 1.5 小时，这些还没完成：\n\n$list\n\n现在补上还来得及。",
                        Notify.CH_CHECKUP, false
                    )
                }
            } catch (e: Exception) { }
            Reminders.scheduleCheckup(ctx)
        }
    }

    private fun handleWeekly(ctx: Context) {
        val week = Prefs.weekIndex(ctx)
        Notify.post(
            ctx, 3000,
            "第 $week 周记录时间",
            "称体重、量腰围，记录本周感受",
            "每周日必做：\n1. 早晨空腹称体重（kg）\n2. 自然站立量腰围（cm）\n3. 写一句本周感受\n\n进「记录」页填写。阶段二目标：腰围每周减 1-2cm。",
            Notify.CH_CHECKUP, false
        )
        Reminders.scheduleWeekly(ctx)
    }

    private fun detailOf(ctx: Context, idx: Int): String {
        val dow = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)
        val day = Prefs.dayIndex(ctx)
        return when (idx) {
            0 -> "起床先喝300ml温水，然后如厕。\n今天第 $day / 100 天 · ${Plan.stage(day)}\n${Plan.scale(day)}"
            1 -> "今天早餐：${Plan.breakfast(dow)}\n（约400千卡，4餐制的地基，别跳过）"
            2 -> "主食三选一：米饭半碗 / 杂粮饭半碗 / 荞麦面一小碗\n" +
                    "蛋白三选一：鸡胸150g / 瘦牛肉150g / 清蒸鱼1条\n" +
                    "蔬菜：2份绿叶菜\n\n外卖备注：少油少盐不要糖，米饭半份。"
            3 -> "吃完午休30分钟，找地方闭眼，别刷手机。定个30分钟闹钟。"
            4 -> "17:00加餐：1个水果 + 一小把坚果（核桃3个或巴旦木8颗），或无糖酸奶1杯。"
            5 -> "晚餐约500千卡，清淡为主：\n杂粮粥半碗 / 燕麦半碗 / 蒸红薯1小个\n" +
                    "+ 豆腐100g / 鸡胸100g / 水煮蛋1个\n+ 1-2份蔬菜\n\n19:30 后不再进食。"
            6 -> {
                val w = Plan.workout(dow)
                "今天：${w.title} · ${w.duration}\n${Plan.scale(day)}\n\n打开「训练」页看动作要领。"
            }
            7 -> "泡脚水温40度左右15-20分钟，同时做全身拉伸：肩颈、胸、背、腿各30秒。"
            8 -> "22:00放下手机，放到够不到的地方。去洗漱，定好明早6:30的闹钟。"
            9 -> "22:30必须上床。硬性规则第1条——做不到，其余全部白费。\n\n现在就把手机放下。"
            else -> ""
        }
    }
}
