package com.body100.plan

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.LinearLayout
import androidx.lifecycle.lifecycleScope
import com.body100.plan.ui.Anim
import com.body100.plan.ui.PlanViewModel
import com.body100.plan.ui.Ui
import com.body100.plan.util.Fx
import com.body100.plan.util.Prefs
import java.util.Calendar

class MealPage(
    private val act: MainActivity,
    private val vm: PlanViewModel,
    private val ui: Ui
) {

    fun build(): LinearLayout {
        val p = ui.page()
        val dow = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)
        val meals = Plan.meals(dow)

        // ---- 顶部 ----
        val hero = ui.card().apply { background = ui.round(ui.orange, 20f) }
        hero.addView(ui.tv("每天4餐 · 1800-2000千卡", 19f, 0xFFFFFFFF.toInt(), true))
        hero.addView(ui.tv("消耗约2400千卡，制造热量缺口", 13f, 0xCCFFFFFF.toInt()))
        p.addView(hero)

        // ---- 原则 ----
        p.addView(ui.section("饮食原则"))
        val rules = ui.card()
        listOf(
            "从「每天一顿」改成4餐，这是关键改变",
            "每天总热量控制在1800-2000千卡",
            "戒酒、戒含糖饮料，只喝白开水 / 淡茶 / 黑咖啡",
            "每天喝够2000-2500ml水",
            "睡前3小时（19:30后）不再进食，只喝水"
        ).forEach { rules.addView(ui.tv("· $it", 14f, ui.ink)) }
        p.addView(rules)

        // ---- 今日食谱 ----
        p.addView(ui.section("今日食谱"))
        for (m in meals) {
            val c = ui.card()
            val head = ui.hbox()
            head.addView(ui.chip(m.time, ui.orange))
            head.addView(ui.wgap(8f))
            head.addView(ui.tv(m.name, 16f, ui.ink, true),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            head.addView(ui.tv(m.kcal, 12f, ui.ink3))
            c.addView(head)

            c.addView(ui.tv(m.content, 14f, ui.ink).apply {
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = ui.dp(8f) }
            })

            val tip = ui.tv("▸ ${m.tip}", 12.5f, ui.ink2).apply {
                background = ui.round(ui.alpha(ui.green, 0.10f), 10f)
                setPadding(ui.dp(10f), ui.dp(10f), ui.dp(10f), ui.dp(10f))
            }
            c.addView(tip, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = ui.dp(8f) })

            c.addView(ui.tv("可替换：${m.swap}", 12f, ui.ink3).apply {
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = ui.dp(6f) }
            })
            p.addView(c)
        }

        // ---- 一周早餐 ----
        p.addView(ui.section("一周早餐速查"))
        val wk = ui.card()
        val dn = listOf("周一", "周二", "周三", "周四", "周五", "周六", "周日")
        for (i in 0..6) {
            val cdow = i + 2
            val today = cdow == dow
            val row = ui.hbox()
            row.addView(ui.tv("${dn[i]}：${Plan.breakfast(cdow)}", 13.5f,
                if (today) ui.orange else ui.ink, today),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.setPadding(0, ui.dp(5f), 0, ui.dp(5f))
            wk.addView(row)
        }
        p.addView(wk)

        // ---- 外卖话术 ----
        p.addView(ui.section("外卖点餐话术"))
        val cpCard = ui.card()
        cpCard.addView(ui.tv("下单备注直接粘贴：", 14f, ui.ink2))
        val note = "少油少盐不要糖，米饭半份，菜多放绿叶菜，谢谢"
        val box = ui.tv(note, 14f, ui.ink).apply {
            background = ui.round(ui.alpha(ui.ink3, 0.12f), 10f)
            setPadding(ui.dp(12f), ui.dp(12f), ui.dp(12f), ui.dp(12f))
        }
        cpCard.addView(box, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = ui.dp(8f) })

        val copyBtn = ui.button("复制话术", ui.green, 0xFFFFFFFF.toInt())
        copyBtn.setOnClickListener {
            try {
                val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("备注", note))
                Fx.playCheck()
                act.toast("已复制，去外卖 app 粘贴")
            } catch (e: Exception) { }
        }
        cpCard.addView(copyBtn, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = ui.dp(10f) })
        p.addView(cpCard)

        // ---- 四餐打卡 ----
        p.addView(ui.section("四餐打卡"))
        val mk = ui.card()
        val ids = listOf("breakfast", "lunch", "snack", "dinner")
        val names = listOf("早餐已吃（07:00）", "午餐已吃（11:30）",
            "加餐已吃（17:00）", "晚餐已吃（19:30前）")
        val boxes = ArrayList<CheckBox>()
        for (i in ids.indices) {
            val cb = ui.check(names[i], false, true)
            cb.setOnClickListener {
                Fx.playCheck()
                Fx.tap(act)
                Anim.pop(it)
                vm.toggleCheck(Prefs.today(), ids[i])
            }
            mk.addView(cb)
            boxes.add(cb)
        }
        p.addView(mk)

        act.lifecycleScope.launchWhenStarted {
            vm.checksOf(Prefs.today()).collect { list ->
                val done = list.filter { it.done }.map { it.itemId }.toSet()
                for (i in ids.indices) {
                    val ok = ids[i] in done
                    if (boxes[i].isChecked != ok) boxes[i].isChecked = ok
                    boxes[i].setTextColor(if (ok) ui.ink3 else ui.ink)
                }
            }
        }

        Anim.stagger(p, 20L)
        return p
    }
}
