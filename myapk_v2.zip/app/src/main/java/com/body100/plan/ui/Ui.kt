package com.body100.plan.ui

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Space
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.body100.plan.R

class Ui(private val ctx: Context) {

    val dark: Boolean by lazy {
        (ctx.resources.configuration.uiMode and
                android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
                android.content.res.Configuration.UI_MODE_NIGHT_YES
    }

    val green: Int get() = col(if (dark) R.color.green_dark2 else R.color.green)
    val orange: Int get() = col(R.color.orange)
    val blue: Int get() = col(R.color.blue)
    val purple: Int get() = col(R.color.purple)
    val red: Int get() = col(R.color.red)
    val ink: Int get() = col(if (dark) R.color.ink_dark else R.color.ink)
    val ink2: Int get() = col(if (dark) R.color.ink2_dark else R.color.ink2)
    val ink3: Int get() = col(if (dark) R.color.ink3 else R.color.ink3)
    val bg: Int get() = col(if (dark) R.color.bg_dark else R.color.bg)
    val card: Int get() = col(if (dark) R.color.card_dark else R.color.card)
    val line: Int get() = col(if (dark) R.color.line_dark else R.color.line)

    fun col(id: Int): Int = ContextCompat.getColor(ctx, id)

    fun dp(v: Float): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    fun round(color: Int, r: Float): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    fun stroke(color: Int, r: Float, strokeColor: Int, w: Float): GradientDrawable =
        round(color, r).apply { setStroke(dp(w).coerceAtLeast(1), strokeColor) }

    fun alpha(c: Int, a: Float): Int {
        val al = (255 * a).toInt()
        return (al shl 24) or (c and 0x00FFFFFF)
    }

    fun vbox(): LinearLayout = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

    fun hbox(): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    fun tv(s: CharSequence, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(ctx).apply {
            text = s
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setLineSpacing(dp(3f).toFloat(), 1f)
        }

    fun gap(h: Float): Space = Space(ctx).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(h))
    }

    fun wgap(w: Float): Space = Space(ctx).apply {
        layoutParams = LinearLayout.LayoutParams(dp(w), 1)
    }

    fun divider(): View = View(ctx).apply {
        setBackgroundColor(line)
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(0.7f).coerceAtLeast(1)
        ).apply { topMargin = dp(10f); bottomMargin = dp(10f) }
    }

    fun card(): LinearLayout = vbox().apply {
        background = round(card, 16f)
        val p = dp(16f)
        setPadding(p, p, p, p)
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(12f) }
        elevation = dp(1f).toFloat()
    }

    /** 左侧色条卡片，返回外层卡片（已包含内容容器） */
    fun barCard(color: Int, onFill: (LinearLayout) -> Unit): LinearLayout {
        val outer = hbox()
        outer.background = round(card, 14f)
        outer.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(10f) }
        val bar = View(ctx).apply { background = round(color, 3f) }
        outer.addView(bar, LinearLayout.LayoutParams(dp(5f), ViewGroup.LayoutParams.MATCH_PARENT))
        val content = vbox()
        content.setPadding(dp(14f), dp(12f), dp(14f), dp(12f))
        outer.addView(content, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        onFill(content)
        return outer
    }

    fun chip(s: String, color: Int): TextView = tv(s, 11f, color, true).apply {
        background = round(alpha(color, 0.12f), 20f)
        setPadding(dp(8f), dp(3f), dp(8f), dp(4f))
    }

    fun button(s: String, bgColor: Int, fg: Int): TextView = tv(s, 15f, fg, true).apply {
        gravity = Gravity.CENTER
        background = round(bgColor, 12f)
        setPadding(dp(14f), dp(12f), dp(14f), dp(12f))
    }

    fun ghost(s: String, color: Int): TextView = tv(s, 14f, color, true).apply {
        gravity = Gravity.CENTER
        background = stroke(card, 12f, color, 1f)
        setPadding(dp(12f), dp(10f), dp(12f), dp(10f))
    }

    fun input(hint: String, value: String, multi: Boolean = false): EditText {
        val cInk = ink
        val cInk3 = ink3
        val cLine = line
        val cDark = dark
        val bgColor = alpha(if (cDark) 0xFF222222.toInt() else 0xFFFBFCFB.toInt(), 1f)
        val px = dp(12f)
        val py = dp(10f)
        return EditText(ctx).apply {
            this.hint = hint
            if (value.isNotEmpty()) setText(value)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setTextColor(cInk)
            setHintTextColor(cInk3)
            background = stroke(bgColor, 10f, cLine, 1f)
            setPadding(px, py, px, py)
            if (multi) {
                minLines = 2
                gravity = Gravity.TOP or Gravity.START
            }
        }
    }

    fun progress(max: Int): ProgressBar {
        val cGreen = green
        val bg = alpha(cGreen, 0.18f)
        return ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal).apply {
            this.max = max
            progress = 0
            try {
                progressTintList = ColorStateList.valueOf(cGreen)
                progressBackgroundTintList = ColorStateList.valueOf(bg)
            } catch (e: Exception) { }
        }
    }

    fun check(label: String, checked: Boolean, strike: Boolean = true): CheckBox {
        val cInk = ink
        val cInk3 = ink3
        val cGreen = green
        val p = dp(8f)
        val pl = dp(4f)
        return CheckBox(ctx).apply {
            text = label
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
            isChecked = checked
            setTextColor(if (checked) cInk3 else cInk)
            if (strike && checked) {
                paintFlags = paintFlags or android.graphics.Paint.STRIKE_THRU_TEXT_FLAG
            }
            try { buttonTintList = ColorStateList.valueOf(cGreen) } catch (e: Exception) { }
            setPadding(pl, p, p, p)
        }
    }

    fun section(s: String): LinearLayout {
        val cGreen = green
        val cInk = ink
        val h = hbox()
        val bar = View(ctx)
        bar.background = round(cGreen, 2f)
        h.addView(bar, LinearLayout.LayoutParams(dp(4f), dp(16f)).apply { rightMargin = dp(8f) })
        h.addView(tv(s, 16f, cInk, true))
        h.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(6f); bottomMargin = dp(10f) }
        return h
    }

    fun scroll(): ScrollView = ScrollView(ctx).apply {
        isFillViewport = true
        clipToPadding = false
        isVerticalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
    }

    fun page(): LinearLayout = vbox().apply {
        setPadding(dp(16f), 0, dp(16f), dp(40f))
    }

    fun colorOf(c: Int): Int = when (c) {
        com.body100.plan.Plan.C_ROOT -> green
        com.body100.plan.Plan.C_MEAL -> orange
        com.body100.plan.Plan.C_TRAIN -> blue
        com.body100.plan.Plan.C_BODY -> purple
        else -> ink3
    }
}
