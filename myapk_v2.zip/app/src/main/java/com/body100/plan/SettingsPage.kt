package com.body100.plan

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import com.body100.plan.ui.Anim
import com.body100.plan.ui.PlanViewModel
import com.body100.plan.ui.Ui
import com.body100.plan.util.Fx
import com.body100.plan.util.Notify
import com.body100.plan.util.Prefs
import com.body100.plan.util.Reminders

class SettingsPage(
    private val act: MainActivity,
    private val vm: PlanViewModel,
    private val ui: Ui
) {

    fun build(): LinearLayout {
        val p = ui.page()
        p.addView(ui.tv("设置", 22f, ui.ink, true))

        val notif = Notify.enabled(act)
        val exact = Reminders.canExact(act)
        val batt = Reminders.batteryOk(act)

        // ---- 健康检查 ----
        val st = ui.card()
        st.addView(ui.tv("提醒健康检查", 16f, ui.ink, true))
        st.addView(ui.gap(6f))
        st.addView(statusLine("通知权限", notif, "未开启时提醒不会出现"))
        st.addView(statusLine("精确闹钟", exact, "未开启会延迟几分钟到几十分钟"))
        st.addView(statusLine("忽略电池优化", batt, "未开启可能被系统杀后台"))
        st.addView(statusLine("提醒总开关", Prefs.alarmsEnabled(act), "关闭后所有闹钟不排"))

        val row1 = ui.hbox()
        val b1 = ui.button("开精确闹钟", ui.green, 0xFFFFFFFF.toInt())
        b1.setOnClickListener { Reminders.openExactSettings(act) }
        val b2 = ui.button("关电池优化", ui.ink, 0xFFFFFFFF.toInt())
        b2.setOnClickListener { Reminders.openBatterySettings(act) }
        row1.addView(b1, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row1.addView(ui.wgap(8f))
        row1.addView(b2, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        st.addView(row1, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = ui.dp(12f) })

        val row2 = ui.hbox()
        val b3 = ui.ghost("通知设置", ui.green)
        b3.setOnClickListener {
            try {
                val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                i.putExtra(Settings.EXTRA_APP_PACKAGE, act.packageName)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                act.startActivity(i)
            } catch (e: Exception) {
                try {
                    act.startActivity(Intent(Settings.ACTION_SETTINGS)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e2: Exception) { }
            }
        }
        val b4 = ui.ghost("应用详情", ui.ink2)
        b4.setOnClickListener {
            try {
                val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                i.setData(Uri.parse("package:${act.packageName}"))
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                act.startActivity(i)
            } catch (e: Exception) { }
        }
        row2.addView(b3, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row2.addView(ui.wgap(8f))
        row2.addView(b4, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        st.addView(row2, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = ui.dp(10f) })
        p.addView(st)

        // ---- 提醒设置 ----
        p.addView(ui.section("提醒设置"))
        val tsw = ui.card()

        val master = ui.check("开启每日提醒", Prefs.alarmsEnabled(act), false)
        master.setOnClickListener { v ->
            Prefs.setAlarmsEnabled(act, (v as CheckBox).isChecked)
            Reminders.rescheduleAll(act)
            act.render()
        }
        tsw.addView(master)
        tsw.addView(ui.tv("每个提醒点响完自动排下一天，重启手机后自动恢复。", 12f, ui.ink3))

        tsw.addView(ui.divider())
        tsw.addView(ui.tv("提前提醒（0-60分钟）", 14f, ui.ink, true))
        val earlyRow = ui.hbox()
        val eIn = ui.input("0", Prefs.earlyMinutes(act).toString())
        eIn.inputType = android.text.InputType.TYPE_CLASS_NUMBER
        val eSave = ui.button("应用", ui.green, 0xFFFFFFFF.toInt())
        eSave.setOnClickListener {
            try {
                val m = eIn.text.toString().trim().toInt()
                Prefs.setEarlyMinutes(act, m)
                Reminders.rescheduleAll(act)
                act.toast("已提前 ${Prefs.earlyMinutes(act)} 分钟")
                act.render()
            } catch (e: Exception) {
                act.toast("请输入 0-60 的数字")
            }
        }
        earlyRow.addView(eIn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        earlyRow.addView(ui.wgap(8f))
        earlyRow.addView(eSave)
        tsw.addView(earlyRow, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = ui.dp(8f) })

        tsw.addView(ui.divider())
        val sound = ui.check("打卡音效", Prefs.soundOn(act), false)
        sound.setOnClickListener { v ->
            Prefs.setSoundOn(act, (v as CheckBox).isChecked)
            Fx.setSound(Prefs.soundOn(act))
            if (Prefs.soundOn(act)) Fx.playCheck()
        }
        tsw.addView(sound)

        val vib = ui.check("打卡震动", Prefs.vibrateOn(act), false)
        vib.setOnClickListener { v ->
            Prefs.setVibrateOn(act, (v as CheckBox).isChecked)
            Fx.setVibrate(Prefs.vibrateOn(act))
            if (Prefs.vibrateOn(act)) Fx.tap(act)
        }
        tsw.addView(vib)

        val checkup = ui.check("21:00 打卡补漏提醒", Prefs.checkupOn(act), false)
        checkup.setOnClickListener { v ->
            Prefs.setCheckupOn(act, (v as CheckBox).isChecked)
            Reminders.scheduleCheckup(act)
        }
        tsw.addView(checkup)

        val weekly = ui.check("周日 20:00 周记录提醒", Prefs.weeklyOn(act), false)
        weekly.setOnClickListener { v ->
            Prefs.setWeeklyOn(act, (v as CheckBox).isChecked)
            Reminders.scheduleWeekly(act)
        }
        tsw.addView(weekly)

        val weatherOn = ui.check("今日页显示天气", Prefs.weatherOn(act), false)
        weatherOn.setOnClickListener { v ->
            Prefs.setWeatherOn(act, (v as CheckBox).isChecked)
            if (Prefs.weatherOn(act)) vm.refreshWeather()
            act.render()
        }
        tsw.addView(weatherOn)
        p.addView(tsw)

        // ---- 提醒清单 ----
        p.addView(ui.section("提醒清单"))
        val list = ui.card()
        val earlyMin = Prefs.earlyMinutes(act)
        for (i in Reminders.POINTS.indices) {
            val pt = Reminders.POINTS[i]
            val m = (pt.minute - earlyMin).coerceAtLeast(0)
            val cb = ui.check("${Reminders.hhmm(m)}   ${pt.title}",
                Prefs.alarmOn(act, pt.key), false)
            cb.setOnClickListener { v ->
                Prefs.setAlarmOn(act, pt.key, (v as CheckBox).isChecked)
                Reminders.rescheduleAll(act)
            }
            list.addView(cb)
        }
        p.addView(list)

        // ---- 自检 ----
        p.addView(ui.section("自检工具"))
        val dbg = ui.card()
        dbg.addView(ui.tv("担心提醒不响？先立刻发一条通知验证权限是否正常。", 14f, ui.ink2))

        val test = ui.button("立刻发一条测试通知", ui.ink, 0xFFFFFFFF.toInt())
        test.setOnClickListener {
            Notify.post(act, 7777, "测试通知 · 正常", "看到这条说明通知权限没问题",
                "今日时间轴：\n06:30 起床喝水\n07:00 早餐\n11:30 午餐\n12:00 午休\n" +
                        "17:00 加餐\n19:30 晚餐\n20:30 训练\n21:30 拉伸泡脚\n22:00 放下手机\n22:30 睡觉")
            Fx.playCheck()
            act.toast("已发送，看看通知栏")
        }
        dbg.addView(test, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = ui.dp(10f) })

        val next = ui.ghost("查看下一条提醒", ui.green)
        next.setOnClickListener { act.toast(Reminders.nextUpText(act)) }
        dbg.addView(next, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = ui.dp(8f) })
        p.addView(dbg)

        // ---- 计划管理 ----
        p.addView(ui.section("计划管理"))
        val mg = ui.card()
        mg.addView(ui.tv("开始日期：${Prefs.startDate(act)}", 14f, ui.ink, true))
        mg.addView(ui.tv("进度按开始日期自动计算，今天是开始后第 ${Prefs.dayIndex(act)} 天。", 12f, ui.ink3))
        val reset = ui.ghost("把开始日期重置为今天", ui.orange)
        reset.setOnClickListener {
            AlertDialog.Builder(act)
                .setTitle("重置开始日期？")
                .setMessage("进度将从今天重新算第1天。已有打卡记录不会删除。")
                .setNegativeButton("取消", null)
                .setPositiveButton("重置") { _, _ ->
                    Prefs.setStartDate(act, Prefs.today())
                    act.render()
                }.show()
        }
        mg.addView(reset, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = ui.dp(10f) })
        p.addView(mg)

        // ---- 关于 ----
        p.addView(ui.section("关于"))
        val ab = ui.card()
        ab.addView(ui.tv("百日计划 v2.0", 15f, ui.ink, true))
        ab.addView(ui.tv("内容 100% 来自《100天身体全面改善执行手册》，未增删训练动作与食谱。\n" +
                "动作示范图来自 free-exercise-db（公有领域）。\n" +
                "天气数据来自 Open-Meteo。\n打卡记录只存本机，不上传。", 13f, ui.ink2))
        ab.addView(ui.divider())
        ab.addView(ui.tv("包名 com.body100.plan", 12f, ui.ink3))
        p.addView(ab)

        Anim.stagger(p, 20L)
        return p
    }

    private fun statusLine(name: String, ok: Boolean, hint: String): LinearLayout {
        val v = ui.vbox()
        v.setPadding(0, ui.dp(4f), 0, ui.dp(4f))
        val h = ui.hbox()
        h.addView(ui.tv(if (ok) "✓" else "✕", 14f, if (ok) ui.green else ui.red, true))
        h.addView(ui.wgap(8f))
        h.addView(ui.tv(name, 14f, ui.ink),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        h.addView(ui.tv(if (ok) "正常" else "需要开启", 13f, if (ok) ui.green else ui.red))
        v.addView(h)
        if (!ok) v.addView(ui.tv("    $hint", 12f, ui.ink3))
        return v
    }
}
