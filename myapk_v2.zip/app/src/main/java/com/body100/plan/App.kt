package com.body100.plan

import android.app.Application
import com.body100.plan.util.Fx
import com.body100.plan.util.Notify
import com.body100.plan.util.Prefs
import com.body100.plan.util.Reminders

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        instance = this
        try {
            Fx.setSound(Prefs.soundOn(this))
            Fx.setVibrate(Prefs.vibrateOn(this))
            Notify.ensure(this)
            Prefs.startDate(this)
            Reminders.rescheduleAll(this)
        } catch (e: Exception) { }
    }

    companion object {
        lateinit var instance: App
            private set
    }
}
