package com.body100.plan

import java.util.Calendar

/** 100天身体全面改善执行手册 —— 全部静态数据 */
object Plan {

    const val C_ROOT = 0xFF0B6E4F.toInt()
    const val C_MEAL = 0xFFE07A1F.toInt()
    const val C_TRAIN = 0xFF2E6BE6.toInt()
    const val C_BODY = 0xFF8E44AD.toInt()
    const val C_WORK = 0xFF6B7280.toInt()

    data class Item(
        val t1: String,
        val t2: String?,
        val title: String,
        val detail: String,
        val howto: String,
        val color: Int
    ) {
        val range: String get() = if (t2 == null) t1 else "$t1-$t2"
    }

    fun schedule(): List<Item> = listOf(
        Item("06:30", null, "起床 · 喝300ml温水 · 如厕", "一天从这条开始",
            "起床先喝温水（前一晚把杯子放床头），然后如厕。不要碰手机。", C_ROOT),
        Item("06:40", "07:00", "拉伸5分钟 + 洗漱", "唤醒身体",
            "肩颈绕环、体侧拉伸、腿上举各1分钟，然后洗漱。", C_BODY),
        Item("07:00", "07:20", "早餐", "约400千卡，不能省",
            "按今天的星期对应食谱吃，别只喝一杯豆浆糊弄。", C_MEAL),
        Item("07:30", "11:30", "上午送餐时段", "中途至少喝一次水",
            "接单间隙喝水，不要空腹跑单。", C_WORK),
        Item("11:30", "12:00", "午餐（一天最丰盛）", "约700千卡",
            "外卖选清蒸/白灼/少油，备注少油少盐不要糖，米饭半份。", C_MEAL),
        Item("12:00", "13:00", "午休 / 闭眼休息30分钟", "别刷手机",
            "找阴凉处闭眼或回家躺下，定30分钟闹钟。", C_BODY),
        Item("13:00", "17:00", "下午送餐时段", "继续喝水",
            "17:00前把当日饮水量补到一半以上。", C_WORK),
        Item("17:00", "17:30", "加餐", "约200千卡，三选一",
            "1个水果+一小把坚果（核桃3个或巴旦木8颗），或无糖酸奶1杯。", C_MEAL),
        Item("17:30", "19:30", "傍晚送餐时段", "19:30前结束",
            "尽量19:30前收工，避免晚餐延后。", C_WORK),
        Item("19:30", "20:30", "晚餐（清淡）", "约500千卡",
            "杂粮粥半碗/燕麦半碗/蒸红薯1小个 + 豆腐100g/鸡胸100g/水煮蛋1个 + 1-2份蔬菜。", C_MEAL),
        Item("20:30", "21:30", "力量训练", "休息日除外",
            "见训练页。练前热身2分钟，练后别立刻坐下。", C_TRAIN),
        Item("21:30", "22:00", "拉伸放松 + 泡脚", "祛湿助眠",
            "泡脚40度左右15-20分钟，同时做全身拉伸。", C_BODY),
        Item("22:00", "22:30", "洗漱，放下手机", "手机放远",
            "定好明早6:30闹钟，洗漱完直接上床。", C_ROOT),
        Item("22:30", null, "必须上床睡觉", "硬性规则第1条",
            "关灯闭眼。今天没完成的，明天再说。", C_ROOT)
    )

    data class Move(val name: String, val how: String, val sets: String, val image: String? = null)

    data class Workout(
        val day: String,
        val title: String,
        val duration: String,
        val slot: String,
        val moves: List<Move>,
        val notes: List<String>
    )

    fun workout(dow: Int): Workout = when (dow) {
        Calendar.MONDAY -> Workout("周一", "胸部 + 上肢", "40分钟", "20:30-21:30", listOf(
            Move("标准俯卧撑", "双手略宽于肩，身体从头到脚一条直线，核心收紧；缓慢下降，胸部贴近地面，手肘约45度。新手先做跪姿俯卧撑过渡。", "4组 x 力竭（组间60秒）", "Pushups"),
            Move("宽距俯卧撑", "双手比肩宽1.5倍，其余同标准俯卧撑；练胸肌外沿，让胸部有轮廓。", "3组 x 8-12次", "Wide-Grip_Push-Up"),
            Move("水瓶侧平举", "两手各持满水500ml水瓶，手肘微屈；向两侧平举至与肩同高，缓慢放下。", "4组 x 15次", "Side_Lateral_Raise"),
            Move("水瓶推举", "双手持瓶于肩部两侧，掌心向前；向上推举至手臂伸直，缓慢放下。", "3组 x 12次", "Dumbbell_Shoulder_Press")
        ), listOf("俯卧撑做不动就先跪姿，别硬撑成塌腰。", "送餐跑一天后肩膀紧张，练前先绕肩1分钟。"))
        Calendar.TUESDAY -> Workout("周二", "核心（腹部）", "35分钟", "20:30-21:30", listOf(
            Move("平板支撑", "手肘撑地，身体从头到脚一条直线，核心收紧；臀部不翘起、不塌陷。", "4组：首周30秒，每周+15秒，第8周起2分钟", "Plank"),
            Move("卷腹", "仰卧屈膝，双手放耳旁（不要抱头）；用腹部力量卷起上半身，肩胛骨离地即可。", "4组 x 15-20次", "Crunches"),
            Move("俄罗斯转体", "坐姿后仰约45度，双脚离地（新手可踩地），抱拳于胸前；左右转体，用手触两侧地面。", "3组 x 20次（左右各10）", "Russian_Twist"),
            Move("仰卧抬腿", "仰卧，双手放身体两侧，双腿伸直；缓慢抬腿至垂直地面，再缓慢放下（不触地）。", "3组 x 12次", "Leg_Raise")
        ), listOf("小腹内脏脂肪是主要目标，平板时长按周递增，别跳级。", "卷腹时腰不要离地，脖子别用力。"))
        Calendar.WEDNESDAY -> Workout("周三", "下肢 + 臀部", "40分钟", "20:30-21:30", listOf(
            Move("标准深蹲", "双脚与肩同宽，像坐椅子一样向后下蹲；大腿与地面平行，腰背挺直、重心在脚跟。", "4组 x 15次", "Bodyweight_Squat"),
            Move("箭步蹲", "一脚向前迈一大步下蹲，前腿大腿与地面平行；后腿膝盖接近地面但不触地，蹬起回站立。", "每条腿 3组 x 10次", "Lunge"),
            Move("提踵", "站立手扶墙保持平衡；踮起脚尖至最高点停顿1秒，缓慢放下。", "4组 x 20次", "Standing_Calf_Raises"),
            Move("臀桥", "仰卧屈膝，双脚踩地；用臀部力量将髋部顶起，顶端停顿2秒。", "4组 x 15次", "Glute_Bridge")
        ), listOf("腿型松垮和久站久走有关，深蹲后务必拉伸前侧和小腿。", "跑一天后做深蹲容易抽筋，练前先补水热身。"))
        Calendar.THURSDAY -> Workout("周四", "休息日（只做拉伸）", "15分钟", "自由", listOf(
            Move("全身拉伸", "肩颈、胸、背、腿各拉伸30秒", "每组30秒", null)
        ), listOf("可以散步30分钟，但不进行力量训练。"))
        Calendar.FRIDAY -> Workout("周五", "全身HIIT燃脂", "25分钟", "20:30-21:30", listOf(
            Move("1. 开合跳", "双脚跳开同时双手上举击掌，再跳回。", "30秒", "Jumping_Jack"),
            Move("2. 高抬腿", "原地快速交替抬腿至大腿与地面平行。", "30秒", "High_Knees"),
            Move("3. 波比跳", "站立-下蹲撑地-后跳成俯卧撑-收回-跳起击掌。", "30秒", "Burpee"),
            Move("4. 登山跑", "俯卧撑姿势，交替快速提膝向胸口。", "30秒", "Mountain_Climbers"),
            Move("5. 深蹲跳", "深蹲后用力向上跳起，落地缓冲。", "30秒", "Squat_Jump")
        ), listOf("节奏：每个动作30秒、休息15秒，循环5轮。", "新手前2周：每个动作20秒、休息20秒、循环3轮。"))
        Calendar.SATURDAY -> Workout("周六", "胸部 + 核心", "40分钟", "20:30-21:30", listOf(
            Move("标准俯卧撑", "双手略宽于肩，身体一条直线，胸部贴地，手肘45度。", "4组 x 力竭", "Pushups"),
            Move("宽距俯卧撑", "双手比肩宽1.5倍，练胸肌外沿。", "3组 x 8-12次", "Wide-Grip_Push-Up"),
            Move("水瓶侧平举", "500ml水瓶各一，平举至肩高，缓慢放下。", "4组 x 15次", "Side_Lateral_Raise"),
            Move("平板支撑", "手肘撑地，身体一条直线，不塌腰不翘臀。", "4组 x 45秒", "Plank"),
            Move("卷腹", "仰卧屈膝，双手放耳旁，肩胛骨离地即可。", "3组 x 15次", "Crunches")
        ), listOf("胸+核心双拼日，40分钟内完成，组间别刷手机。"))
        else -> Workout("周日", "休息日（散步/拉伸）", "自由", "自由", listOf(
            Move("全身拉伸", "肩颈、胸、背、腿各拉伸30秒", "每组30秒", null)
        ), listOf("散步30分钟即可，不进行力量训练，为下周储备体力。"))
    }

    data class Meal(val time: String, val name: String, val kcal: String,
                    val content: String, val tip: String, val swap: String)

    private val BREAKFAST = listOf(
        "水煮蛋2个 + 全麦面包2片 + 无糖豆浆1杯",
        "燕麦粥1碗（无糖）+ 水煮蛋1个 + 牛奶1杯",
        "全麦馒头1个 + 水煮蛋2个 + 黑咖啡1杯",
        "杂粮粥1碗 + 水煮蛋1个 + 豆浆1杯",
        "全麦面包2片 + 水煮蛋2个 + 牛奶1杯",
        "燕麦粥1碗 + 水煮蛋1个 + 黑咖啡1杯",
        "全麦馒头1个 + 水煮蛋2个 + 无糖豆浆1杯"
    )

    fun breakfastIndex(dow: Int) = if (dow == Calendar.SUNDAY) 6 else dow - 1

    fun breakfast(dow: Int) = BREAKFAST[breakfastIndex(dow)]

    fun meals(dow: Int): List<Meal> = listOf(
        Meal("07:00", "早餐", "约400千卡", breakfast(dow),
            "早餐是4餐制的地基，跳过早餐等于当天计划作废。", "主食可互换：面包/馒头/粥等效"),
        Meal("11:30", "午餐（一天最丰盛）", "约700千卡",
            "主食三选一：米饭半碗 / 杂粮饭半碗 / 荞麦面一小碗\n蛋白三选一：鸡胸肉150g / 瘦牛肉150g / 清蒸鱼1条\n蔬菜：2份绿叶菜（西兰花、菠菜、生菜）",
            "只允许清蒸、白灼、水煮、少油快炒；绝不吃油炸、红烧、糖醋。", "外卖备注：少油少盐不要糖，米饭半份"),
        Meal("17:00", "加餐", "约200千卡",
            "1个水果（苹果/香蕉/橙子）+ 一小把坚果（核桃3个或巴旦木8颗），或无糖酸奶1杯",
            "三选一，不要都吃；坚果按颗数数，别抓一把。", "苹果/香蕉/橙子可互换"),
        Meal("19:30", "晚餐（清淡）", "约500千卡",
            "主食三选一：杂粮粥半碗 / 燕麦半碗 / 蒸红薯1小个\n蛋白三选一：豆腐100g / 鸡胸肉100g / 水煮蛋1个\n蔬菜：1-2份，凉拌、白灼最佳",
            "19:30之后不再进食，只喝水。", "实在饿就喝温水或无糖茶，不加餐")
    )

    data class CheckItem(val id: String, val title: String, val time: String)

    val CHECKS = listOf(
        CheckItem("wake", "06:30 起床，喝300ml温水", "06:30"),
        CheckItem("breakfast", "早餐按时吃完（不跳过）", "07:00"),
        CheckItem("water", "全天饮水2000ml以上", "21:00"),
        CheckItem("lunch", "午餐少油少盐，半份主食+足量蔬菜蛋白", "11:30"),
        CheckItem("nap", "午休30分钟（不刷手机）", "12:00"),
        CheckItem("snack", "17:00加餐（水果+坚果 / 无糖酸奶）", "17:00"),
        CheckItem("dinner", "晚餐清淡，19:30前吃完", "19:30"),
        CheckItem("noeat", "19:30后不再进食", "19:30"),
        CheckItem("nodrink", "全天未喝酒、未喝含糖饮料", "22:00"),
        CheckItem("train", "完成当日训练 / 拉伸", "20:30"),
        CheckItem("stretch", "21:30 拉伸 + 泡脚", "21:30"),
        CheckItem("phone", "22:00 放下手机", "22:00"),
        CheckItem("sleep", "22:30 上床睡觉", "22:30")
    )

    val RED_LINES = listOf(
        "熬夜超过 22:30", "不吃早餐", "喝酒", "含糖饮料",
        "油炸 / 红烧 / 糖醋", "19:30 后进食"
    )

    val RULES = listOf(
        "22:30 必须睡，早上 6:30 必须起",
        "每天4餐，一顿都不能省（尤其早餐）",
        "戒酒，100天内一滴不沾",
        "戒含糖饮料，只喝白开水 / 淡茶 / 黑咖啡",
        "外卖备注少油少盐不要糖，不吃油炸、红烧、糖醋",
        "每天训练不缺席（休息日除外）",
        "每天喝够 2000ml 水",
        "睡前3小时（19:30后）不进食"
    )

    fun stage(day: Int): String = when {
        day <= 14 -> "阶段一 · 适应期"
        day <= 56 -> "阶段二 · 强化期"
        else -> "阶段三 · 冲刺期"
    }

    fun stageGoals(day: Int): List<String> = when {
        day <= 14 -> listOf(
            "只改饮食+作息，运动从每天20分钟做起，训练减半",
            "目标：让身体适应「4餐 + 早睡早起 + 每天动一动」",
            "这两周不追求效果，追求「不断」")
        day <= 56 -> listOf(
            "全量执行所有计划，每周日称体重、量腰围并记录",
            "目标：腰围每周减1-2cm，体重下降2-4kg",
            "每周记录填一次，别估，用数字说话")
        else -> listOf(
            "加大强度：俯卧撑全标准版，平板加到2分钟，HIIT满5轮",
            "目标：胸肌轮廓明显、小肚子基本平、体态挺拔",
            "冲刺期最容易放弃，撑过第9周就稳了")
    }

    fun scale(day: Int): String = when {
        day <= 14 -> "阶段一减半：俯卧撑2组、平板30秒x2组，运动20分钟起步"
        day <= 56 -> "阶段二全量：按训练页组次原样执行"
        else -> "阶段三加强：俯卧撑标准版、平板2分钟、HIIT满5轮"
    }
}
