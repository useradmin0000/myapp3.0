# Room
-keep class com.body100.plan.data.** { *; }
-keepclassmembers class * extends androidx.room.RoomDatabase {
    public static ** INSTANCE;
}

# Kotlin metadata
-keepattributes *Annotation*, InnerClasses, Signature, Exceptions
